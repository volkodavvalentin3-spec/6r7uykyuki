--[[
  Melon Commander: Garage
  Submod "Создание своих машин" / "Build your own vehicles".
  Requires the Melon Commander: RTS addon.
]]--

local root = "melon_commander_vehicles/"

local sharedFiles = {
  "shared/core.lua",
  "shared/parts.lua",
  "shared/vehicle.lua"
}

local serverFiles = {
  "server/vehicles.lua"
}

local clientFiles = {
  "client/visual.lua",
  "client/garage.lua"
}

if SERVER then
  for _, file in ipairs(sharedFiles) do AddCSLuaFile(root .. file) end
  for _, file in ipairs(clientFiles) do AddCSLuaFile(root .. file) end
end

-- Melon Commander calls this hook once its base content is registered, on both server and client.
hook.Add("melon_commander_load_expansions", "melon_commander_vehicles_load", function()
  for _, file in ipairs(sharedFiles) do include(root .. file) end

  if SERVER then
    for _, file in ipairs(serverFiles) do include(root .. file) end
  else
    for _, file in ipairs(clientFiles) do include(root .. file) end
  end
end)
