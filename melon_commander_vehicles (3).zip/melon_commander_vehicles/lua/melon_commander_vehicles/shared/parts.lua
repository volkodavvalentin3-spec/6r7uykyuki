--[[
  Melon Commander: Garage - the part catalog.

  Slots and the fields they understand (all numbers are balance values, tweak freely):

  Hull    Length/Width/Height (units), Mass, Health, Cost, SpeedMul?,
          MinAxles?/MaxAxles, MaxWheelRadius, ModuleSlots, DecorSlots,
          Mounts = { { x, y, c } }  -- weapon mounts: x/y are fractions of half length / half width, c = class 1..3

  Wheel   Model, Radius, Speed (base speed), Cost/Mass/Health (per wheel), Contact? (ram damage per axle)

  Engine  Power, Mass, Cost, SpeedMul?, Health?, Color, Glow?

  Armor   Cost, Mass, HealthMul, SpeedMul?, DamageMult?, Thickness, Color

  Module  Faction? ("Base:Vanilla" etc: only for that faction), Cost, Mass, SpeedAdd?, HealthAdd?, DamageMult?, Regen?, Contact?, HealAura?/HealRadius?, Income?,
          Stackable?, Shape, Size, Color

  Decor   Cost, Mass?, Visuals = { { Shape, Pos, Size, Color | Tint } }  (relative to the decor spot)

  Add your own with MelonCommander.Vehicles.RegisterPart(slot, id, def).
]]--

local V = MelonCommander.Vehicles

local function T(ru, en)
  return { ru = ru, en = en }
end

-- Hulls -----------------------------------------------------------------------------------------------

V.RegisterPart("Hull", "kart", {
  Name = T("Карт", "Kart"),
  Length = 56, Width = 34, Height = 8,
  Mass = 55, Health = 70, Cost = 60,
  MinAxles = 1, MaxAxles = 2, MaxWheelRadius = 12,
  ModuleSlots = 1, DecorSlots = 2,
  Mounts = {
    { x = -0.3, y = 0, c = 1 }
  }
})

V.RegisterPart("Hull", "buggy", {
  Name = T("Багги", "Buggy"),
  Length = 76, Width = 42, Height = 9,
  Mass = 110, Health = 110, Cost = 110,
  MinAxles = 2, MaxAxles = 3, MaxWheelRadius = 15,
  ModuleSlots = 2, DecorSlots = 3,
  Mounts = {
    { x = -0.55, y = 0, c = 1 },
    { x = -0.05, y = 0, c = 1 }
  }
})

V.RegisterPart("Hull", "racer", {
  Name = T("Гоночная рама", "Racer frame"),
  Length = 92, Width = 36, Height = 6,
  Mass = 80, Health = 65, Cost = 200, SpeedMul = 1.15,
  MinAxles = 2, MaxAxles = 2, MaxWheelRadius = 14,
  ModuleSlots = 2, DecorSlots = 3,
  Mounts = {
    { x = -0.4, y = 0, c = 1 }
  }
})

V.RegisterPart("Hull", "pickup", {
  Name = T("Пикап", "Pickup"),
  Length = 100, Width = 48, Height = 10,
  Mass = 170, Health = 170, Cost = 180,
  MinAxles = 2, MaxAxles = 3, MaxWheelRadius = 18,
  ModuleSlots = 3, DecorSlots = 3,
  Mounts = {
    { x = -0.75, y = 0, c = 2 },
    { x = -0.35, y = 0.5, c = 1 },
    { x = -0.35, y = -0.5, c = 1 }
  }
})

V.RegisterPart("Hull", "truck", {
  Name = T("Грузовик", "Truck"),
  Length = 130, Width = 56, Height = 12,
  Mass = 300, Health = 260, Cost = 280,
  MinAxles = 2, MaxAxles = 4, MaxWheelRadius = 20,
  ModuleSlots = 4, DecorSlots = 4,
  Mounts = {
    { x = -0.8, y = 0, c = 2 },
    { x = -0.45, y = 0, c = 2 },
    { x = -0.05, y = 0.5, c = 1 },
    { x = -0.05, y = -0.5, c = 1 }
  }
})

V.RegisterPart("Hull", "apc", {
  Name = T("БТР", "APC"),
  Length = 120, Width = 62, Height = 14,
  Mass = 450, Health = 420, Cost = 400,
  MinAxles = 2, MaxAxles = 4, MaxWheelRadius = 22,
  ModuleSlots = 4, DecorSlots = 4,
  Mounts = {
    { x = -0.65, y = 0, c = 2 },
    { x = -0.2, y = 0.5, c = 2 },
    { x = -0.2, y = -0.5, c = 2 },
    { x = 0.15, y = 0, c = 3 }
  }
})

V.RegisterPart("Hull", "hauler", {
  Name = T("Тяжёлый тягач", "Heavy hauler"),
  Length = 170, Width = 72, Height = 16,
  Mass = 650, Health = 600, Cost = 600,
  MinAxles = 3, MaxAxles = 5, MaxWheelRadius = 24,
  ModuleSlots = 6, DecorSlots = 5,
  Mounts = {
    { x = -0.8, y = 0, c = 3 },
    { x = -0.5, y = 0.5, c = 2 },
    { x = -0.5, y = -0.5, c = 2 },
    { x = -0.15, y = 0.5, c = 2 },
    { x = -0.15, y = -0.5, c = 2 },
    { x = 0.15, y = 0, c = 3 }
  }
})

V.RegisterPart("Hull", "mega", {
  Name = T("Мега-платформа", "Mega platform"),
  Length = 230, Width = 100, Height = 18,
  Mass = 1100, Health = 950, Cost = 1000,
  MinAxles = 3, MaxAxles = 6, MaxWheelRadius = 26,
  ModuleSlots = 8, DecorSlots = 6,
  Mounts = {
    { x = -0.82, y = 0.45, c = 3 },
    { x = -0.82, y = -0.45, c = 3 },
    { x = -0.55, y = 0, c = 2 },
    { x = -0.3, y = 0.5, c = 2 },
    { x = -0.3, y = -0.5, c = 2 },
    { x = 0.0, y = 0.5, c = 2 },
    { x = 0.0, y = -0.5, c = 2 },
    { x = 0.18, y = 0, c = 2 }
  }
})

-- Wheels ------------------------------------------------------------------------------------------------

V.RegisterPart("Wheel", "melon", {
  Name = T("Арбузные колёса", "Melon wheels"),
  Model = "models/props_junk/watermelon01.mdl",
  Radius = 7, Speed = 6.0, Cost = 5, Mass = 3, Health = 1
})

V.RegisterPart("Wheel", "moped", {
  Name = T("Мопедные колёса", "Moped wheels"),
  Model = "models/props_phx/wheels/moped_tire.mdl",
  Radius = 7, Speed = 6.8, Cost = 8, Mass = 3, Health = 0
})

V.RegisterPart("Wheel", "highway", {
  Name = T("Шоссейные колёса", "Highway wheels"),
  Model = "models/props_vehicles/tire001c_car.mdl",
  Radius = 11, Speed = 8.5, Cost = 18, Mass = 6, Health = 2
})

V.RegisterPart("Wheel", "sport", {
  Name = T("Спортивные колёса", "Sport wheels"),
  Model = "models/props_phx/wheels/drugster_back.mdl",
  Radius = 12, Speed = 9.8, Cost = 34, Mass = 5, Health = 0
})

V.RegisterPart("Wheel", "light", {
  Name = T("Лёгкие колёса", "Light wheels"),
  Model = "models/props_phx/normal_tire.mdl",
  Radius = 12, Speed = 7.6, Cost = 15, Mass = 5, Health = 1
})

V.RegisterPart("Wheel", "truck", {
  Name = T("Грузовые колёса", "Truck wheels"),
  Model = "models/props_vehicles/tire001b_truck.mdl",
  Radius = 15, Speed = 7.0, Cost = 26, Mass = 12, Health = 6
})

V.RegisterPart("Wheel", "bigtruck", {
  Name = T("Большегрузные колёса", "Heavy truck wheels"),
  Model = "models/props_phx/trucktire.mdl",
  Radius = 17, Speed = 6.6, Cost = 28, Mass = 14, Health = 7
})

V.RegisterPart("Wheel", "armored", {
  Name = T("Бронеколёса", "Armored wheels"),
  Model = "models/props_vehicles/apc_tire001.mdl",
  Radius = 16, Speed = 6.2, Cost = 42, Mass = 20, Health = 14
})

V.RegisterPart("Wheel", "tractor", {
  Name = T("Тракторные колёса", "Tractor wheels"),
  Model = "models/props_vehicles/tire001a_tractor.mdl",
  Radius = 19, Speed = 5.4, Cost = 30, Mass = 16, Health = 10
})

V.RegisterPart("Wheel", "monster", {
  Name = T("Колёса монстр-трака", "Monster truck wheels"),
  Model = "models/props_phx/wheels/monster_truck.mdl",
  Radius = 22, Speed = 6.6, Cost = 55, Mass = 22, Health = 12, Contact = 3
})

V.RegisterPart("Wheel", "gear", {
  Name = T("Шестерни", "Gear wheels"),
  Model = "models/Mechanics/gears2/gear_18t2.mdl",
  Radius = 14, Speed = 5.8, Cost = 24, Mass = 14, Health = 4, Contact = 2
})

V.RegisterPart("Wheel", "saw", {
  Name = T("Колёса-пилы", "Saw blade wheels"),
  Model = "models/props_junk/sawblade001a.mdl",
  Radius = 13, Speed = 7.0, Cost = 40, Mass = 10, Health = 1, Contact = 8
})

-- Engines -----------------------------------------------------------------------------------------------

V.RegisterPart("Engine", "moped", {
  Name = T("Моторчик", "Little motor"),
  Power = 110, Mass = 18, Cost = 25,
  Color = Color(150, 150, 150)
})

V.RegisterPart("Engine", "i4", {
  Name = T("Рядная четвёрка", "Inline-4"),
  Power = 240, Mass = 45, Cost = 60,
  Color = Color(120, 125, 130)
})

V.RegisterPart("Engine", "v6", {
  Name = T("V6", "V6"),
  Power = 420, Mass = 70, Cost = 120,
  Color = Color(110, 130, 150)
})

V.RegisterPart("Engine", "v8", {
  Name = T("V8", "V8"),
  Power = 650, Mass = 105, Cost = 210,
  Color = Color(160, 110, 100)
})

V.RegisterPart("Engine", "diesel", {
  Name = T("Дизель", "Diesel"),
  Power = 560, Mass = 130, Cost = 180, Health = 25,
  Color = Color(90, 95, 80)
})

V.RegisterPart("Engine", "turbo", {
  Name = T("Турбо V8", "Turbo V8"),
  Power = 900, Mass = 120, Cost = 340,
  Color = Color(170, 90, 60)
})

V.RegisterPart("Engine", "reactor", {
  Name = T("Реактор", "Reactor"),
  Power = 1300, Mass = 170, Cost = 600,
  Color = Color(70, 110, 150), Glow = Color(120, 200, 255)
})

V.RegisterPart("Engine", "melonium", {
  Name = T("Мелониевое ядро", "Melonium core"),
  Power = 1700, Mass = 140, Cost = 900,
  Color = Color(60, 120, 60), Glow = Color(120, 255, 120)
})

-- Armor -------------------------------------------------------------------------------------------------

V.RegisterPart("Armor", "sheet", {
  Name = T("Листовая сталь", "Sheet steel"),
  Cost = 60, Mass = 30, HealthMul = 1.20, SpeedMul = 0.98,
  Thickness = 1.5, Color = Color(110, 115, 120)
})

V.RegisterPart("Armor", "steel", {
  Name = T("Стальные плиты", "Steel plates"),
  Cost = 110, Mass = 55, HealthMul = 1.35, SpeedMul = 0.96,
  Thickness = 2.5, Color = Color(85, 90, 95)
})

V.RegisterPart("Armor", "composite", {
  Name = T("Композитная броня", "Composite armor"),
  Cost = 190, Mass = 60, HealthMul = 1.50, SpeedMul = 0.95,
  Thickness = 3, Color = Color(70, 80, 70)
})

V.RegisterPart("Armor", "ceramic", {
  Name = T("Керамическая броня", "Ceramic armor"),
  Cost = 270, Mass = 85, HealthMul = 1.65, SpeedMul = 0.93,
  Thickness = 3.5, Color = Color(210, 205, 190)
})

V.RegisterPart("Armor", "spaced", {
  Name = T("Экранированная броня", "Spaced armor"),
  Cost = 240, Mass = 70, HealthMul = 1.30, SpeedMul = 0.95, DamageMult = 0.88,
  Thickness = 4, Color = Color(95, 100, 85)
})

V.RegisterPart("Armor", "reactive", {
  Name = T("Динамическая защита", "Reactive armor"),
  Cost = 320, Mass = 80, HealthMul = 1.25, SpeedMul = 0.94, DamageMult = 0.80,
  Thickness = 3.5, Color = Color(120, 90, 60)
})

V.RegisterPart("Armor", "rind", {
  Name = T("Арбузная корка", "Watermelon rind"),
  Cost = 380, Mass = 110, HealthMul = 1.80, SpeedMul = 0.90,
  Thickness = 4.5, Color = Color(50, 140, 60)
})

-- Modules -----------------------------------------------------------------------------------------------

V.RegisterPart("Module", "repair", {
  Name = T("Ремкомплект", "Repair kit"),
  Cost = 90, Mass = 10, Regen = 2.0,
  Shape = "cube", Size = Vector(8, 8, 6), Color = Color(220, 60, 60)
})

V.RegisterPart("Module", "nano", {
  Name = T("Нано-ремонт", "Nano repair"),
  Cost = 220, Mass = 16, Regen = 5.0,
  Shape = "cube", Size = Vector(7, 7, 7), Color = Color(80, 220, 230)
})

V.RegisterPart("Module", "nitro", {
  Name = T("Нитро-ускоритель", "Nitro booster"),
  Cost = 110, Mass = 14, SpeedAdd = 0.18,
  Shape = "cylinder", Size = Vector(5, 5, 9), Color = Color(60, 110, 230)
})

V.RegisterPart("Module", "suspension", {
  Name = T("Спортивная подвеска", "Sport suspension"),
  Cost = 70, Mass = 12, SpeedAdd = 0.08, HealthAdd = 0.05,
  Shape = "cube", Size = Vector(10, 10, 3), Color = Color(30, 30, 35)
})

V.RegisterPart("Module", "ram", {
  Name = T("Таранный бампер", "Ram bumper"),
  Cost = 90, Mass = 28, Contact = 18, HealthAdd = 0.08,
  Shape = "cube", Size = Vector(5, 14, 6), Color = Color(130, 135, 140)
})

V.RegisterPart("Module", "spikes", {
  Name = T("Шипы", "Spikes"),
  Cost = 40, Mass = 8, Contact = 9,
  Shape = "cone", Size = Vector(6, 6, 9), Color = Color(150, 150, 155)
})

V.RegisterPart("Module", "shield", {
  Name = T("Генератор щита", "Shield generator"),
  Cost = 210, Mass = 22, DamageMult = 0.82,
  Shape = "sphere", Size = Vector(9, 9, 9), Color = Color(90, 160, 255)
})

V.RegisterPart("Module", "plating", {
  Name = T("Скрытое бронирование", "Hidden plating"),
  Cost = 80, Mass = 26, HealthAdd = 0.15,
  Shape = "cube", Size = Vector(12, 6, 2), Color = Color(60, 62, 66)
})

V.RegisterPart("Module", "cage", {
  Name = T("Каркас безопасности", "Roll cage"),
  Cost = 100, Mass = 20, HealthAdd = 0.05, DamageMult = 0.93,
  Shape = "cube", Size = Vector(14, 10, 2), Color = Color(160, 160, 165)
})

V.RegisterPart("Module", "medic", {
  Name = T("Мед-станция", "Medic station"),
  Cost = 180, Mass = 18, HealAura = 4, HealRadius = 160,
  Shape = "cube", Size = Vector(8, 8, 8), Color = Color(240, 240, 240)
})

V.RegisterPart("Module", "gun", {
  Name = T("Доп. пулемёт", "Extra machine gun"),
  Cost = 120, Mass = 14, Gun = true, Stackable = true,
  Visuals = {
    { Shape = "cube", Pos = Vector(0, 0, 1.5), Size = Vector(7, 7, 3), Color = Color(45, 45, 50) },
    { Shape = "cube", Pos = Vector(8, 0, 4.5), Size = Vector(14, 1.8, 1.8), Color = Color(30, 30, 33) },
    { Shape = "cube", Pos = Vector(-1, 0, 4), Size = Vector(6, 3.5, 3.5), Color = Color(60, 60, 66) }
  }
})

V.RegisterPart("Module", "cargo", {
  Name = T("Десантный отсек (6 юнитов)", "Cargo bay (6 units)"),
  Cost = 150, Mass = 30, Cargo = true, Unique = true,
  Shape = "cube", Size = Vector(16, 14, 5), Color = Color(95, 100, 85)
})

V.RegisterPart("Module", "kamikaze", {
  Name = T("Камикадзе", "Kamikaze"),
  Cost = 200, Mass = 35, Stackable = true,
  Kamikaze = { Damage = 450, Radius = 170 },
  Visuals = {
    { Shape = "cube", Pos = Vector(0, 0, 3), Size = Vector(12, 12, 6), Color = Color(170, 40, 35) },
    { Shape = "cylinder", Pos = Vector(0, 0, 8), Size = Vector(3, 3, 6), Color = Color(240, 200, 60) }
  }
})

V.RegisterPart("Module", "factory", {
  Name = T("Передвижной завод", "Mobile factory"),
  Cost = 900, Mass = 50, Stackable = true,
  Factory = { Max = 3, IntervalMul = 0.6, MinInterval = 6 },
  Shape = "cube", Size = Vector(16, 14, 6), Color = Color(110, 100, 70)
})

V.RegisterPart("Module", "mothership", {
  Name = T("Мини-носитель (москиты)", "Mothership (mosquitos)"),
  Cost = 520, Mass = 45,
  Spawner = { Unit = "Base:Mosquito", Interval = 24, Max = 3 },
  Stackable = true,
  Shape = "cylinder", Size = Vector(13, 13, 4), Color = Color(80, 90, 110)
})

V.RegisterPart("Module", "collector", {
  Name = T("Водосборник", "Water collector"),
  Cost = 400, Mass = 20, Income = 3,
  Shape = "cylinder", Size = Vector(8, 8, 10), Color = Color(70, 150, 230)
})

-- Faction modules: available only to the faction in the Faction field (the "Any faction" chaos setting lifts this).
V.RegisterPart("Module", "vanilla_kit", {
  Name = T("[Vanilla] Полевой ремкомплект", "[Vanilla] Field repair kit"),
  Faction = "Base:Vanilla", Unique = true,
  -- Unique effect: heals allies nearby and patches the hull up once when it gets low on health.
  Cost = 320, Mass = 20, SpeedAdd = 0.05, HealthAdd = 0.08, Regen = 1.0,
  HealAura = 3, HealRadius = 190,
  EmergencyRepair = { Threshold = 0.3, Heal = 0.4, Cooldown = 45 },
  Visuals = {
    { Shape = "cube", Pos = Vector(0, 0, 2), Size = Vector(10, 8, 4), Color = Color(70, 130, 200) },
    { Shape = "cube", Pos = Vector(0, 0, 5), Size = Vector(4, 4, 2), Color = Color(240, 240, 240) }
  }
})

V.RegisterPart("Module", "empire_bastion", {
  Name = T("[Империя] Осадный бастион", "[Empire] Siege bastion"),
  Faction = "Base:Empire", Unique = true,
  -- Unique effect: when the vehicle stands still it digs in (less damage taken, fast repair).
  Cost = 420, Mass = 70, HealthAdd = 0.25,
  Siege = { Delay = 2.0, Reduction = 0.4, Regen = 4 },
  Visuals = {
    { Shape = "cube", Pos = Vector(0, 0, 3), Size = Vector(14, 14, 6), Color = Color(120, 110, 95) },
    { Shape = "cube", Pos = Vector(0, 0, 7), Size = Vector(9, 9, 3), Color = Color(150, 135, 100) }
  }
})

V.RegisterPart("Module", "falcon_booster", {
  Name = T("[Falcon] Ионный реактор", "[Falcon] Ion reactor"),
  Faction = "Base:Falcon", Unique = true,
  -- Unique effect: an ion pulse hits all enemies around the vehicle every few seconds.
  Cost = 400, Mass = 20, SpeedAdd = 0.15,
  Pulse = { Damage = 140, Radius = 260, Interval = 25 },
  Visuals = {
    { Shape = "cylinder", Pos = Vector(-3, 0, 3), Size = Vector(7, 7, 12), Color = Color(210, 215, 225) },
    { Shape = "cone", Pos = Vector(-10, 0, 3), Size = Vector(6, 6, 5), Color = Color(255, 150, 50) }
  }
})

V.RegisterPart("Module", "void_spikes", {
  Name = T("[Void] Ядовитые шипы", "[Void] Venom spikes"),
  Faction = "Base:Void", Unique = true,
  -- Unique effect: every enemy rammed gets poisoned and keeps taking damage for a few seconds.
  Cost = 360, Mass = 30, Contact = 25, Regen = 1.5, HealthAdd = 0.05,
  Poison = { Dps = 14, Duration = 6 },
  Visuals = {
    { Shape = "cube", Pos = Vector(0, 0, 2), Size = Vector(12, 12, 4), Color = Color(60, 20, 90) },
    { Shape = "cone", Pos = Vector(0, 0, 7), Size = Vector(5, 5, 7), Color = Color(150, 60, 220) }
  }
})

-- Decorations -------------------------------------------------------------------------------------------

V.RegisterPart("Decor", "antenna", {
  Name = T("Антенна", "Antenna"),
  Cost = 8,
  Visuals = {
    { Shape = "cylinder", Pos = Vector(0, 0, 12), Size = Vector(1.2, 1.2, 24), Color = Color(40, 40, 45) },
    { Shape = "sphere", Pos = Vector(0, 0, 25), Size = Vector(3, 3, 3), Color = Color(255, 60, 60) }
  }
})

V.RegisterPart("Decor", "flag", {
  Name = T("Флаг", "Flag"),
  Cost = 10,
  Visuals = {
    { Shape = "cylinder", Pos = Vector(0, 0, 11), Size = Vector(1, 1, 22), Color = Color(200, 200, 205) },
    { Shape = "cube", Pos = Vector(0, 4, 18), Size = Vector(0.6, 8, 5), Tint = 1.0 }
  }
})

V.RegisterPart("Decor", "spoiler", {
  Name = T("Спойлер", "Spoiler"),
  Cost = 14,
  Visuals = {
    { Shape = "cube", Pos = Vector(0, 0, 6), Size = Vector(6, 24, 1.5), Tint = 0.6 },
    { Shape = "cube", Pos = Vector(0, 8, 3), Size = Vector(1.5, 1.5, 6), Color = Color(30, 30, 35) },
    { Shape = "cube", Pos = Vector(0, -8, 3), Size = Vector(1.5, 1.5, 6), Color = Color(30, 30, 35) }
  }
})

V.RegisterPart("Decor", "lights", {
  Name = T("Фары", "Headlights"),
  Cost = 12,
  Visuals = {
    { Shape = "sphere", Pos = Vector(0, 8, 3), Size = Vector(5, 5, 5), Color = Color(255, 245, 170) },
    { Shape = "sphere", Pos = Vector(0, -8, 3), Size = Vector(5, 5, 5), Color = Color(255, 245, 170) }
  }
})

V.RegisterPart("Decor", "siren", {
  Name = T("Мигалка", "Siren"),
  Cost = 16,
  Visuals = {
    { Shape = "cube", Pos = Vector(0, -4, 2), Size = Vector(5, 5, 4), Color = Color(230, 40, 40) },
    { Shape = "cube", Pos = Vector(0, 4, 2), Size = Vector(5, 5, 4), Color = Color(40, 80, 240) }
  }
})

V.RegisterPart("Decor", "barrel", {
  Name = T("Бочка", "Barrel"),
  Cost = 10,
  Visuals = {
    { Shape = "cylinder", Pos = Vector(0, 0, 9), Size = Vector(12, 12, 18), Color = Color(180, 45, 35) }
  }
})

V.RegisterPart("Decor", "exhaust", {
  Name = T("Выхлопные трубы", "Exhaust pipes"),
  Cost = 12,
  Visuals = {
    { Shape = "cylinder", Pos = Vector(0, 5, 8), Size = Vector(3, 3, 16), Color = Color(60, 60, 65) },
    { Shape = "cylinder", Pos = Vector(0, -5, 8), Size = Vector(3, 3, 16), Color = Color(60, 60, 65) }
  }
})

V.RegisterPart("Decor", "searchlight", {
  Name = T("Прожектор", "Searchlight"),
  Cost = 18,
  Visuals = {
    { Shape = "cube", Pos = Vector(0, 0, 2), Size = Vector(7, 7, 4), Color = Color(40, 40, 45) },
    { Shape = "sphere", Pos = Vector(0, 0, 7), Size = Vector(9, 9, 9), Color = Color(240, 240, 200) }
  }
})

V.RegisterPart("Decor", "cone", {
  Name = T("Конус на крыше", "Roof cone"),
  Cost = 6,
  Visuals = {
    { Shape = "cone", Pos = Vector(0, 0, 7), Size = Vector(10, 10, 14), Color = Color(255, 120, 0) }
  }
})

V.RegisterPart("Decor", "melon", {
  Name = T("Арбуз-талисман", "Melon mascot"),
  Cost = 5,
  Visuals = {
    { Shape = "sphere", Pos = Vector(0, 0, 6), Size = Vector(11, 11, 11), Color = Color(70, 170, 60) },
    { Shape = "sphere", Pos = Vector(0, 0, 12), Size = Vector(3, 3, 3), Color = Color(240, 60, 70) }
  }
})

V.RegisterPart("Decor", "rack", {
  Name = T("Багажник на крышу", "Roof rack"),
  Cost = 12,
  Visuals = {
    { Shape = "cube", Pos = Vector(0, 0, 4), Size = Vector(24, 18, 1), Color = Color(35, 35, 40) },
    { Shape = "cube", Pos = Vector(8, 0, 2), Size = Vector(1.5, 16, 3), Color = Color(35, 35, 40) },
    { Shape = "cube", Pos = Vector(-8, 0, 2), Size = Vector(1.5, 16, 3), Color = Color(35, 35, 40) }
  }
})
