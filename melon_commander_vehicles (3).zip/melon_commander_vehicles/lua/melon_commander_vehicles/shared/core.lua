--[[
  Melon Commander: Garage
  Submod "Создание своих машин" / "Build your own vehicles".

  Shared core: constants, part registry, design (blueprint) validation,
  layout geometry and stat calculation. Everything in this file is pure
  data / math, so it behaves identically on the server and on the client.

  Vehicle frame ("VF"): x = forward, y = left, z = up, origin = centre of the hull box.
  Entity-local frame: VF rotated around Z by V.FrontYaw (see ToEntityLocal).
]]--

MelonCommander.Vehicles = MelonCommander.Vehicles or {}
local V = MelonCommander.Vehicles

-- Identifiers ---------------------------------------------------------------

V.UnitId = MelonCommander.Utility.String.Namespaced("Garage", "Vehicle")
V.ComponentId = MelonCommander.Utility.String.Namespaced("Garage", "VehicleBody")
V.IntentKind = "PlaceVehicle"

-- Name of the NW2 string that carries the compact blueprint to the clients.
V.NWCode = "McvCode"

-- Model-local yaw of the direction in which the vehicle drives.
-- If vehicles drive sideways on your install, change this to 0 (or 180 / -90).
V.FrontYaw = 90

-- Attached weapon units cost this share of their normal price (same as base turret mode).
V.WeaponDiscount = 0.75

V.MaxNameLength = 32

-- Chaos settings -------------------------------------------------------------------------------
-- Server-wide switches (replicated convars). Admins change them in the "Tools" tab of the command panel
-- or with: melon_commander_vehicles_chaos <AnyUnit|IgnoreFaction|IgnoreMounts|IgnoreLimits|Free> <0|1>

V.SettingOrder = { "AnyUnit", "IgnoreFaction", "IgnoreMounts", "IgnoreLimits", "Free" }

V.SettingConVarNames = {
  AnyUnit = "melon_commander_vehicles_any_unit",
  IgnoreFaction = "melon_commander_vehicles_ignore_faction",
  IgnoreMounts = "melon_commander_vehicles_ignore_mount_class",
  IgnoreLimits = "melon_commander_vehicles_ignore_limits",
  Free = "melon_commander_vehicles_free"
}

V.ConVars = V.ConVars or {}

for _, key in ipairs(V.SettingOrder) do
  if V.ConVars[key] == nil then
    V.ConVars[key] = CreateConVar(
      V.SettingConVarNames[key], "0",
      FCVAR_ARCHIVE + FCVAR_REPLICATED + FCVAR_NOTIFY,
      "Melon Commander: Garage chaos setting "..key, 0, 1
    )
  end
end

function V.Setting(key)
  local convar = V.ConVars[key]
  if convar == nil then return false end

  return convar:GetBool()
end

-- Highest number of wheel pairs / module slots / decor slots the hull allows right now.
function V.MaxAxles(hull)
  if V.Setting("IgnoreLimits") then return math.max(hull.MaxAxles, 10) end

  return hull.MaxAxles
end

function V.ModuleSlotCount(hull)
  if V.Setting("IgnoreLimits") then return hull.ModuleSlots + 8 end

  return hull.ModuleSlots
end

function V.DecorSlotCount(hull)
  if V.Setting("IgnoreLimits") then return hull.DecorSlots + 8 end

  return hull.DecorSlots
end

function V.MaxWheelRadius(hull)
  if V.Setting("IgnoreLimits") then return 1000 end

  return hull.MaxWheelRadius
end

-- Heaviest weapon class a mount takes: its own class plus one (a light mount takes medium units too).
function V.MountMaxClass(mount)
  if V.Setting("IgnoreMounts") then return 3 end

  return math.min(3, mount.c + 1)
end

-- Can this weapon unit be bolted on this mount?
function V.MountAccepts(mount, id)
  return V.WeaponClass(id) <= V.MountMaxClass(mount)
end

-- Models -----------------------------------------------------------------------

V.Models = {
  -- Tiny model used only as the "physical" body of the unit entity. It is never drawn.
  Body = "models/props_junk/watermelon01.mdl",

  -- Primitives that all clientside visuals are made from (auto-fitted to size).
  Cube = "models/hunter/blocks/cube1x1x1.mdl",
  Sphere = "models/hunter/misc/sphere075x075.mdl",
  Cylinder = "models/props_c17/oildrum001.mdl",
  Cone = "models/props_junk/TrafficCone001a.mdl",

  Fallback = "models/props_junk/watermelon01.mdl"
}

-- Small helpers ------------------------------------------------------------------

local function clamp(x, lo, hi)
  if x < lo then return lo end
  if x > hi then return hi end
  return x
end

V.Clamp = clamp

-- Interface language (client): auto = follow the game's language, or force ru / en.
if CLIENT then
  CreateClientConVar("melon_commander_vehicles_lang", "auto", true, false, "Garage language: auto, ru or en")
end

local function round(x)
  return math.floor(x + 0.5)
end

function V.GetLang()
  if CLIENT then
    local cv = GetConVar("melon_commander_vehicles_lang")
    local forced = cv and cv:GetString() or "auto"

    if forced == "ru" or forced == "en" then return forced end

    local gl = GetConVar("gmod_language")
    local lang = gl and gl:GetString() or "en"
    if lang == "ru" or lang == "uk" or lang == "be" or lang == "kk" then return "ru" end
  end

  return "en"
end

-- Localised text: either a plain string or { ru = "...", en = "..." }
function V.Text(v)
  if type(v) == "table" then
    local lang = V.GetLang()
    return v[lang] or v.en or v.ru or ""
  end

  return tostring(v or "")
end

-- Part registry ------------------------------------------------------------------

V.Slots = { "Hull", "Wheel", "Engine", "Armor", "Module", "Decor" }

V.Parts = V.Parts or {}
V.PartOrder = V.PartOrder or {}

for _, slot in ipairs(V.Slots) do
  V.Parts[slot] = V.Parts[slot] or {}
  V.PartOrder[slot] = V.PartOrder[slot] or {}
end

--[[
  Other addons can add their own parts:
    MelonCommander.Vehicles.RegisterPart("Wheel", "myid", { Name = "...", ... })
  See parts.lua for the fields that every slot understands.
]]--
function V.RegisterPart(slot, id, def)
  local registry = V.Parts[slot]
  if registry == nil then
    error("unknown vehicle part slot "..tostring(slot))
    return
  end

  if type(id) ~= "string" or id == "" or string.find(id, "[|,;]") then
    error("invalid vehicle part id "..tostring(id))
    return
  end

  def.Id = id
  def.Slot = slot

  if registry[id] == nil then
    table.insert(V.PartOrder[slot], id)
  end

  registry[id] = def
  return def
end

function V.GetPart(slot, id)
  local registry = V.Parts[slot]
  if registry == nil or id == nil or id == "" then return nil end

  return registry[id]
end

-- Blueprint ---------------------------------------------------------------------------

--[[
  design = {
    Name    = "My car",
    Hull    = "buggy",
    Wheel   = "highway",
    Axles   = 2,                       -- pairs of wheels
    Engine  = "i4",
    Armor   = "",                      -- "" = none
    Modules = { "turbo", "repair" },
    Decor   = { "antenna" },
    Weapons = { "Base:Marine", "" },   -- one entry per hull mount, "" = empty; any unit id with a weapon
  }
]]--

function V.DefaultDesign()
  return {
    Name = "",
    Hull = "buggy",
    Wheel = "highway",
    Axles = 2,
    Engine = "i4",
    Armor = "",
    Modules = {},
    Decor = {},
    Weapons = { "", "" },
    Factory = ""
  }
end

function V.CopyDesign(design)
  local copy = {
    Name = design.Name or "",
    Hull = design.Hull,
    Wheel = design.Wheel,
    Axles = design.Axles,
    Engine = design.Engine,
    Armor = design.Armor or "",
    Modules = {},
    Decor = {},
    Weapons = {},
    Factory = design.Factory or ""
  }

  for i, v in ipairs(design.Modules or {}) do copy.Modules[i] = v end
  for i, v in ipairs(design.Decor or {}) do copy.Decor[i] = v end
  for i, v in ipairs(design.Weapons or {}) do copy.Weapons[i] = v end

  return copy
end

-- Weapons ("units that are attached") ------------------------------------------------------

local forbiddenWeaponFlags = {
  Air = true,
  Prop = true,
  Outpost = true
}

--[[
  Which units can be bolted on a vehicle as a weapon? Any unit that has a weapon of its own
  and doesn't need to move/fly/stand frozen on the ground by itself.
]]--
function V.IsWeaponUnit(id)
  if type(id) ~= "string" or id == "" or id == V.UnitId then return false end

  local template = MelonCommander.Units[id]
  if template == nil then return false end

  -- Chaos mode: (almost) any registered unit can be bolted on - except buildings, planes and bases.
  if V.Setting("AnyUnit") then
    if (template.OutpostRadius or 0) > 0 then return false end

    for _, flag in ipairs(template.Flags or {}) do
      if flag == "Air" or flag == "Building" or flag == "Outpost" or flag == "PointOfInterest" then return false end
    end

    if template.Locomotor ~= nil and template.Locomotor ~= "" then
      local locomotor = MelonCommander.Locomotors[template.Locomotor]
      if locomotor ~= nil and locomotor.MoveType == MelonCommander.LocomotorMoveType.Air then
        return false
      end
    end

    return true
  end

  if not template.Buildable then return false end
  if template.CanBeTurret == false then return false end
  if template.Weapon == nil or template.Weapon == "" then return false end
  if (template.OutpostRadius or 0) > 0 then return false end

  local weaponTemplate = MelonCommander.Weapons[template.Weapon]
  if weaponTemplate == nil then return false end

  -- Those weapons teleport (SetAngles) the unit every shot, which would tear the weld apart.
  if weaponTemplate.RotateTowardsTarget then return false end

  for _, flag in ipairs(template.Flags or {}) do
    if forbiddenWeaponFlags[flag] then return false end
  end

  if template.Locomotor ~= nil and template.Locomotor ~= "" then
    local locomotor = MelonCommander.Locomotors[template.Locomotor]
    if locomotor ~= nil and locomotor.MoveType == MelonCommander.LocomotorMoveType.Air then
      return false
    end
  end

  local physics = MelonCommander.GetUnitTemplateComponent(id, MelonCommander.Expansions.Base.Component.Physics)
  if physics ~= nil and physics.Parameters ~= nil and physics.Parameters.MoveType == MOVETYPE_NONE then
    return false
  end

  return true
end

-- 1 = light, 2 = medium, 3 = heavy. A mount accepts weapons of its own class or lighter.
function V.WeaponClass(id)
  local template = MelonCommander.Units[id]
  if template == nil then return 3 end

  local cost = template.BuildCost or 0
  if cost <= 150 then return 1 end
  if cost <= 400 then return 2 end

  return 3
end

function V.WeaponCost(id)
  local template = MelonCommander.Units[id]
  if template == nil then return 0 end

  return math.floor((template.BuildCost or 0) * V.WeaponDiscount)
end

function V.WeaponMass(id)
  local template = MelonCommander.Units[id]
  if template == nil then return 0 end

  return 10 + (template.BuildCost or 0) * 0.06
end

function V.WeaponName(id)
  local template = MelonCommander.Units[id]
  if template == nil then return tostring(id) end

  return template.DisplayName or tostring(id)
end

--[[
  List of unit ids that a player of the given faction can mount as weapons,
  sorted by price. mountClass (optional) filters out weapons that are too heavy.
]]--
function V.GetAvailableWeapons(factionId, mountClass)
  local result = {}

  local ignoreFaction = V.Setting("IgnoreFaction") or V.Setting("AnyUnit")
  if V.Setting("IgnoreMounts") then mountClass = nil end

  local candidates = {}

  if ignoreFaction then
    for id, _ in pairs(MelonCommander.Units) do
      table.insert(candidates, id)
    end
  else
    local faction = MelonCommander.Factions[factionId]
    if faction == nil then return result end

    candidates = faction.AvailableUnits or {}
  end

  local seen = {}
  for _, id in ipairs(candidates) do
    if not seen[id] then
      seen[id] = true

      local banned = false
      if not ignoreFaction then
        banned = MelonCommander.GameRules ~= nil
          and MelonCommander.GameRules.BannedUnits ~= nil
          and MelonCommander.GameRules.BannedUnits[id] ~= nil
      end

      if not banned and V.IsWeaponUnit(id) then
        if mountClass == nil or V.WeaponClass(id) <= mountClass then
          table.insert(result, id)
        end
      end
    end
  end

  table.sort(result, function(a, b)
    local ta, tb = MelonCommander.Units[a], MelonCommander.Units[b]
    if (ta.BuildCost or 0) ~= (tb.BuildCost or 0) then
      return (ta.BuildCost or 0) < (tb.BuildCost or 0)
    end

    return a < b
  end)

  return result
end

-- Faction-locked modules (Module.Faction): only that faction may use them, unless faction limits are off.
function V.ModuleAllowed(module, factionId)
  if module == nil then return false end
  if module.Faction == nil then return true end
  if factionId == nil or factionId == "" then return true end
  if V.Setting("IgnoreFaction") or V.Setting("AnyUnit") then return true end

  return module.Faction == factionId
end

-- Validation ------------------------------------------------------------------------------------

--[[
  Takes an untrusted design table and returns a clean copy of it, or nil + error text.
  ctx (optional): { IsWeaponAllowed = function(unitId) -> bool }
]]--
function V.NormalizeDesign(raw, ctx)
  if type(raw) ~= "table" then return nil, "Bad blueprint" end

  local hull = V.GetPart("Hull", raw.Hull)
  if hull == nil then return nil, "Unknown hull" end

  local wheel = V.GetPart("Wheel", raw.Wheel)
  if wheel == nil then return nil, "Unknown wheels" end

  if wheel.Radius > V.MaxWheelRadius(hull) then
    return nil, "These wheels are too big for this hull"
  end

  local engine = V.GetPart("Engine", raw.Engine)
  if engine == nil then return nil, "Unknown engine" end

  local design = {
    Name = "",
    Hull = raw.Hull,
    Wheel = raw.Wheel,
    Axles = 1,
    Engine = raw.Engine,
    Armor = "",
    Modules = {},
    Decor = {},
    Weapons = {},
    Factory = ""
  }

  if type(raw.Name) == "string" then
    design.Name = string.sub(raw.Name, 1, V.MaxNameLength)
  end

  local axles = tonumber(raw.Axles) or 1
  design.Axles = clamp(round(axles), hull.MinAxles or 1, V.MaxAxles(hull))

  if raw.Armor ~= nil and raw.Armor ~= "" then
    if V.GetPart("Armor", raw.Armor) == nil then return nil, "Unknown armor" end
    design.Armor = raw.Armor
  end

  local usedModules = {}
  if type(raw.Modules) == "table" then
    for _, id in ipairs(raw.Modules) do
      local module = V.GetPart("Module", id)
      if module == nil then return nil, "Unknown module" end
      if not V.ModuleAllowed(module, ctx ~= nil and ctx.FactionId or nil) then return nil, "This module belongs to another faction" end
      if usedModules[id] and (module.Unique or (not module.Stackable and not V.Setting("IgnoreLimits"))) then return nil, "Duplicate module" end
      usedModules[id] = true

      table.insert(design.Modules, id)
    end
  end

  if #design.Modules > V.ModuleSlotCount(hull) then return nil, "Too many modules for this hull" end

  -- Mobile factory modules produce one kind of unit (chosen per blueprint, falls back to the first allowed one).
  local needsFactory = false
  for _, id in ipairs(design.Modules) do
    if V.GetPart("Module", id).Factory ~= nil then needsFactory = true end
  end

  if needsFactory then
    local choices = V.GetFactoryUnits(ctx ~= nil and ctx.FactionId or nil)

    local chosen = ""
    for _, id in ipairs(choices) do
      if id == raw.Factory then chosen = id end
    end

    if chosen == "" then chosen = choices[1] or "" end
    if chosen == "" then return nil, "No light units are available for the mobile factory" end

    design.Factory = chosen
  end

  if type(raw.Decor) == "table" then
    for _, id in ipairs(raw.Decor) do
      if V.GetPart("Decor", id) == nil then return nil, "Unknown decoration" end

      table.insert(design.Decor, id)
    end
  end

  if #design.Decor > V.DecorSlotCount(hull) then return nil, "Too many decorations for this hull" end

  local rawWeapons = raw.Weapons
  if type(rawWeapons) ~= "table" then rawWeapons = {} end

  for i, mount in ipairs(hull.Mounts) do
    local id = rawWeapons[i]
    if type(id) ~= "string" then id = "" end

    if id ~= "" then
      if not V.IsWeaponUnit(id) then return nil, "This unit can't be mounted: "..id end
      if not V.MountAccepts(mount, id) then return nil, "Weapon is too heavy for mount "..tostring(i) end

      if ctx ~= nil and ctx.IsWeaponAllowed ~= nil and not ctx.IsWeaponAllowed(id) then
        return nil, "Weapon is not available: "..id
      end
    end

    design.Weapons[i] = id
  end

  return design
end

-- Compact blueprint string (sent to clients through an NW2 string) ----------------------------------

local function splitPlain(str, sep)
  local result = {}
  local start = 1

  while true do
    local from, to = string.find(str, sep, start, true)
    if from == nil then
      table.insert(result, string.sub(str, start))
      break
    end

    table.insert(result, string.sub(str, start, from - 1))
    start = to + 1
  end

  return result
end

local function splitList(str)
  if str == nil or str == "" then return {} end

  return splitPlain(str, ",")
end

function V.EncodeCode(design)
  return table.concat({
    design.Hull,
    design.Wheel,
    tostring(design.Axles),
    design.Engine,
    design.Armor or "",
    table.concat(design.Modules or {}, ","),
    table.concat(design.Decor or {}, ",")
  }, "|")
end

-- Visual-only design: weapons are not part of it (they are separate unit entities).
function V.DecodeCode(code)
  if type(code) ~= "string" or code == "" then return nil end

  local fields = splitPlain(code, "|")
  if #fields < 7 then return nil end

  local hull = V.GetPart("Hull", fields[1])
  if hull == nil then return nil end
  if V.GetPart("Wheel", fields[2]) == nil then return nil end
  if V.GetPart("Engine", fields[4]) == nil then return nil end

  local design = {
    Name = "",
    Hull = fields[1],
    Wheel = fields[2],
    Axles = clamp(round(tonumber(fields[3]) or 1), hull.MinAxles or 1, math.max(hull.MaxAxles, 10)),
    Engine = fields[4],
    Armor = fields[5],
    Modules = {},
    Decor = {},
    Weapons = {}
  }

  if design.Armor ~= "" and V.GetPart("Armor", design.Armor) == nil then design.Armor = "" end

  for _, id in ipairs(splitList(fields[6])) do
    if V.GetPart("Module", id) ~= nil then table.insert(design.Modules, id) end
  end

  for _, id in ipairs(splitList(fields[7])) do
    if V.GetPart("Decor", id) ~= nil then table.insert(design.Decor, id) end
  end

  return design
end

-- Geometry --------------------------------------------------------------------------------------------

-- Vehicle frame -> entity-local frame
function V.ToEntityLocal(v)
  local rad = math.rad(V.FrontYaw)
  local c, s = math.cos(rad), math.sin(rad)

  return Vector(v.x * c - v.y * s, v.x * s + v.y * c, v.z)
end

-- Where decorations may sit (fractions of half length / half width on the top surface).
local decorSpots = {
  { -0.88, 0.0 },
  { 0.0, 0.0 },
  { 0.88, 0.5 },
  { 0.88, -0.5 },
  { -0.88, 0.62 },
  { -0.88, -0.62 },
  { 0.3, 0.8 },
  { 0.3, -0.8 }
}

local function moduleSpot(index, count, hull)
  local side = (index % 2 == 1) and 1 or -1
  local row = math.ceil(index / 2)
  local rows = math.max(math.ceil(count / 2), 1)

  local t = 0
  if rows > 1 then t = (row - 1) / (rows - 1) end

  local fx = -0.78 + t * 1.2
  return Vector(fx * hull.Length / 2, side * 0.78 * hull.Width / 2, hull.Height / 2)
end

local function decorSpot(index, hull)
  local spot = decorSpots[((index - 1) % #decorSpots) + 1]
  return Vector(spot[1] * hull.Length / 2, spot[2] * hull.Width / 2, hull.Height / 2)
end

local function addVisual(list, shape, pos, size, color, tint)
  table.insert(list, {
    Shape = shape,
    Pos = pos,
    Size = size,
    Color = color,
    Tint = tint
  })
end

--[[
  Returns everything needed to build and draw a vehicle:
    Length/Width/Height, Mins/Maxs (physics box, entity-local), Radius,
    Wheels  = { { Pos (VF), Radius, Side }, ... },
    Mounts  = { { Pos (VF, top surface of the hull), Class }, ... },
    Visuals = { { Shape, Pos (VF), Size, Color | Tint }, ... }
]]--
function V.ComputeLayout(design)
  local hull = V.GetPart("Hull", design.Hull)
  local wheel = V.GetPart("Wheel", design.Wheel)
  local engine = V.GetPart("Engine", design.Engine)
  if hull == nil or wheel == nil or engine == nil then return nil end

  local L, W, H = hull.Length, hull.Width, hull.Height
  local R = wheel.Radius
  local clearance = R * 1.1
  local wheelWidth = R * 0.55

  local layout = {
    Length = L,
    Width = W,
    Height = H,
    WheelRadius = R,
    Clearance = clearance,
    Wheels = {},
    Mounts = {},
    Visuals = {}
  }

  -- Physics box (entity-local). Hull-centred, extended downwards to reach the ground.
  local rad = math.rad(V.FrontYaw)
  local c, s = math.abs(math.cos(rad)), math.abs(math.sin(rad))

  local ex = c * L / 2 + s * W / 2
  local ey = s * L / 2 + c * W / 2

  layout.Mins = Vector(-ex, -ey, -H / 2 - clearance)
  layout.Maxs = Vector(ex, ey, H / 2)
  layout.Radius = math.sqrt((L / 2) * (L / 2) + (W / 2) * (W / 2))

  -- Wheels
  local axles = design.Axles
  local xMin = -L / 2 + R * 0.9
  local xMax = L / 2 - R * 0.9
  if xMax < xMin then xMin, xMax = 0, 0 end

  local wheelZ = -H / 2 - clearance + R
  local wheelY = W / 2 + wheelWidth * 0.5

  for i = 1, axles do
    local t = 0.5
    if axles > 1 then t = (i - 1) / (axles - 1) end

    local x = xMin + (xMax - xMin) * t

    table.insert(layout.Wheels, { Pos = Vector(x, wheelY, wheelZ), Radius = R, Side = 1 })
    table.insert(layout.Wheels, { Pos = Vector(x, -wheelY, wheelZ), Radius = R, Side = -1 })
  end

  -- Weapon mounts
  for _, m in ipairs(hull.Mounts) do
    table.insert(layout.Mounts, {
      Pos = Vector(m.x * L / 2, m.y * W / 2, H / 2),
      Class = m.c
    })
  end

  -- Hull
  addVisual(layout.Visuals, "cube", Vector(0, 0, 0), Vector(L, W, H), nil, 1.0)

  -- Skirt that closes the gap between the hull and the (lowered) ground line
  addVisual(layout.Visuals, "cube",
    Vector(0, 0, -H / 2 - clearance * 0.3),
    Vector(L * 0.9, W * 0.8, clearance * 0.6), Color(35, 35, 38), nil)

  -- Engine block at the front
  local engineScale = 0.75 + clamp(engine.Power / 1800, 0, 1) * 0.55
  local engineHeight = H * 0.9 * engineScale + 3
  addVisual(layout.Visuals, "cube",
    Vector(L * 0.32, 0, H / 2 + engineHeight / 2),
    Vector(L * 0.24, W * 0.62, engineHeight), engine.Color or Color(120, 120, 125), nil)

  if engine.Glow then
    addVisual(layout.Visuals, "sphere",
      Vector(L * 0.32, 0, H / 2 + engineHeight + 2),
      Vector(W * 0.2, W * 0.2, W * 0.2), engine.Glow, nil)
  end

  -- Armor plating
  local armor = V.GetPart("Armor", design.Armor)
  if armor ~= nil then
    local t = armor.Thickness or 2.5
    local plateColor = armor.Color or Color(90, 95, 100)

    addVisual(layout.Visuals, "cube", Vector(0, W / 2 + t / 2, 0), Vector(L * 0.92, t, H * 1.5), plateColor, nil)
    addVisual(layout.Visuals, "cube", Vector(0, -W / 2 - t / 2, 0), Vector(L * 0.92, t, H * 1.5), plateColor, nil)
    addVisual(layout.Visuals, "cube", Vector(L / 2 + t / 2, 0, 0), Vector(t, W, H * 1.5), plateColor, nil)
    addVisual(layout.Visuals, "cube", Vector(-L / 2 - t / 2, 0, 0), Vector(t, W, H * 1.5), plateColor, nil)
  end

  -- Modules
  for i, id in ipairs(design.Modules) do
    local module = V.GetPart("Module", id)
    if module ~= nil then
      local spot = moduleSpot(i, #design.Modules, hull)

      if module.Visuals ~= nil then
        for _, v in ipairs(module.Visuals) do
          addVisual(layout.Visuals, v.Shape or "cube",
            Vector(spot.x + v.Pos.x, spot.y + v.Pos.y, spot.z + v.Pos.z),
            v.Size, v.Color, v.Tint)
        end
      else
        local size = module.Size or Vector(8, 8, 6)

        spot.z = spot.z + size.z / 2
        addVisual(layout.Visuals, module.Shape or "cube", spot, size, module.Color or Color(200, 200, 200), nil)
      end
    end
  end

  -- Decorations
  for i, id in ipairs(design.Decor) do
    local decor = V.GetPart("Decor", id)
    if decor ~= nil and decor.Visuals ~= nil then
      local spot = decorSpot(i, hull)

      for _, v in ipairs(decor.Visuals) do
        addVisual(layout.Visuals, v.Shape or "cube",
          Vector(spot.x + v.Pos.x, spot.y + v.Pos.y, spot.z + v.Pos.z),
          v.Size, v.Color, v.Tint)
      end
    end
  end

  return layout
end

-- Stats --------------------------------------------------------------------------------------------------

--[[
  Returns a table with:
    Cost, PartsCost, WeaponsCost, BuildTime, Health, Speed, Mass, DamageMult, Regen,
    ContactDamage, HealAura, HealAuraRadius, Income, PartCount, WeaponCount, PartBonus
]]--
function V.ComputeStats(design)
  local hull = V.GetPart("Hull", design.Hull)
  local wheel = V.GetPart("Wheel", design.Wheel)
  local engine = V.GetPart("Engine", design.Engine)
  if hull == nil or wheel == nil or engine == nil then return nil end

  local armor = V.GetPart("Armor", design.Armor)
  local wheelCount = design.Axles * 2

  local partsCost = hull.Cost + wheelCount * wheel.Cost + engine.Cost
  local mass = hull.Mass + wheelCount * wheel.Mass + engine.Mass
  local flatHealth = hull.Health + wheelCount * (wheel.Health or 0) + (engine.Health or 0)
  local healthMul = 1
  local speedMul = (hull.SpeedMul or 1) * (engine.SpeedMul or 1)
  local damageMult = 1
  local regen = 0
  local contact = (wheel.Contact or 0) * design.Axles
  local aura = 0
  local auraRadius = 0
  local income = 0
  local spawners = {}
  local swarmMax = 0
  local gunCount = 0
  local cargo = false
  local factoryCount = 0
  local kamikazeDamage = 0
  local kamikazeRadius = 0
  local repair, siege, pulse, poison = nil, nil, nil, nil

  if armor ~= nil then
    partsCost = partsCost + armor.Cost
    mass = mass + armor.Mass
    healthMul = healthMul * (armor.HealthMul or 1)
    speedMul = speedMul * (armor.SpeedMul or 1)
    damageMult = damageMult * (armor.DamageMult or 1)
  end

  local partCount = 1 + wheelCount + 1 + (armor ~= nil and 1 or 0)

  for _, id in ipairs(design.Modules) do
    local module = V.GetPart("Module", id)
    if module ~= nil then
      partCount = partCount + 1
      partsCost = partsCost + module.Cost
      mass = mass + module.Mass

      speedMul = speedMul * (1 + (module.SpeedAdd or 0))
      healthMul = healthMul + (module.HealthAdd or 0)
      damageMult = damageMult * (module.DamageMult or 1)
      regen = regen + (module.Regen or 0)
      contact = contact + (module.Contact or 0)
      income = income + (module.Income or 0)

      if module.Gun then gunCount = gunCount + 1 end
      if module.Factory ~= nil then factoryCount = factoryCount + 1 end

      if module.Kamikaze ~= nil then
        kamikazeDamage = kamikazeDamage + module.Kamikaze.Damage
        kamikazeRadius = math.max(kamikazeRadius, module.Kamikaze.Radius)
      end
      if module.Cargo then cargo = true end
      repair = module.EmergencyRepair or repair
      siege = module.Siege or siege
      pulse = module.Pulse or pulse
      poison = module.Poison or poison

      if module.Spawner ~= nil then
        table.insert(spawners, module.Spawner)
        swarmMax = swarmMax + (module.Spawner.Max or 0)
      end

      if (module.HealAura or 0) > aura then
        aura = module.HealAura
        auraRadius = module.HealRadius or 160
      end
    end
  end

  for _, id in ipairs(design.Decor) do
    local decor = V.GetPart("Decor", id)
    if decor ~= nil then
      partCount = partCount + 1
      partsCost = partsCost + decor.Cost
      mass = mass + (decor.Mass or 2)
    end
  end

  local weaponsCost = 0
  local weaponCount = 0
  local maxWeaponBuildTime = 0

  for _, id in ipairs(design.Weapons) do
    if id ~= "" then
      weaponCount = weaponCount + 1
      weaponsCost = weaponsCost + V.WeaponCost(id)
      mass = mass + V.WeaponMass(id)

      local template = MelonCommander.Units[id]
      if template ~= nil and (template.BuildTime or 0) > maxWeaponBuildTime then
        maxWeaponBuildTime = template.BuildTime
      end
    end
  end

  partCount = partCount + weaponCount

  -- "The more parts the better": every installed part makes the vehicle a bit sturdier.
  local partBonus = math.min(0.5, partCount * 0.012)

  local health = math.floor(flatHealth * healthMul * (1 + partBonus))

  local perf = clamp(math.sqrt(engine.Power / mass), 0.4, 1.5)

  -- The smaller the vehicle, the faster it is (a kart is much quicker than a land battleship).
  local sizeMul = clamp((110 / hull.Length) ^ 0.6, 0.6, 1.5)
  -- 0.5: keeps the fastest vehicles in the same league as the fastest base units (Scout = 7).
  local speed = clamp(wheel.Speed * perf * speedMul * sizeMul * 0.5, 2.0, 10)

  if V.Setting("Free") then
    partsCost = 0
    weaponsCost = 0
  end

  local cost = math.ceil(partsCost + weaponsCost)
  local buildTime = clamp(4 + cost / 45, 6, 50)
  buildTime = math.max(buildTime, maxWeaponBuildTime)

  return {
    Cost = cost,
    PartsCost = math.ceil(partsCost),
    WeaponsCost = weaponsCost,
    BuildTime = buildTime,
    Health = health,
    Speed = speed,
    Mass = mass,
    DamageMult = damageMult,
    Regen = regen,
    ContactDamage = contact,
    HealAura = aura,
    HealAuraRadius = auraRadius,
    Income = income,
    SizeMul = sizeMul,
    Spawners = spawners,
    GunCount = gunCount,
    FactoryCount = factoryCount,
    KamikazeDamage = kamikazeDamage,
    KamikazeRadius = kamikazeRadius,
    Cargo = cargo,
    EmergencyRepair = repair,
    Siege = siege,
    Pulse = pulse,
    Poison = poison,
    SwarmMax = swarmMax,
    PartCount = partCount,
    WeaponCount = weaponCount,
    PartBonus = partBonus
  }
end


-- The built-in machine gun that the "Extra machine gun" module gives to a vehicle.
-- More guns shoot proportionally faster.
function V.BuildGunWeapon(count)
  local base = MelonCommander.Weapons[MelonCommander.Expansions.Base.Weapon.MachineGun]
  if base == nil then return nil end

  local weapon = table.Copy(base)
  weapon.FireDelay = base.FireDelay / math.max(count, 1)

  return weapon
end


-- Mobile factory: which units may it produce? ---------------------------------------------------------------------------

V.FactoryMaxCost = 180

-- A "light" ground unit: cheap, walks on the ground, not a building / prop / outpost.
function V.IsFactoryUnit(id)
  local template = MelonCommander.Units[id]
  if template == nil or id == V.UnitId then return false end
  if not template.Buildable then return false end

  for _, flag in ipairs(template.Flags or {}) do
    if flag == "Air" or flag == "Building" or flag == "Prop" or flag == "Outpost" or flag == "PointOfInterest" then
      return false
    end
  end

  if (template.OutpostRadius or 0) > 0 then return false end

  if template.Locomotor == nil or template.Locomotor == "" then return false end

  local locomotor = MelonCommander.Locomotors[template.Locomotor]
  if locomotor == nil or locomotor.MoveType == MelonCommander.LocomotorMoveType.Air then return false end

  -- Hover units (jetpacks) fly low: they use an air-like locomotor in some versions.
  if V.Setting("AnyUnit") then return true end

  return (template.BuildCost or 0) <= V.FactoryMaxCost
end

--[[
  Units a mobile factory of this faction can produce: light ground units that are unique to the faction
  (Scout for Vanilla, Laser Scout for Falcon, ...). Chaos "Any unit" lifts the light/unique restriction,
  "Units of every faction" (or no faction given) looks at every faction's unique units.
]]--
function V.GetFactoryUnits(factionId)
  local memberCount = {}
  for _, faction in pairs(MelonCommander.Factions) do
    local seen = {}
    for _, id in ipairs(faction.AvailableUnits or {}) do
      if not seen[id] then
        seen[id] = true
        memberCount[id] = (memberCount[id] or 0) + 1
      end
    end
  end

  local anyUnit = V.Setting("AnyUnit")
  local ignoreFaction = anyUnit or V.Setting("IgnoreFaction") or factionId == nil

  local candidates = {}
  if ignoreFaction then
    for id, _ in pairs(MelonCommander.Units) do table.insert(candidates, id) end
  else
    local faction = MelonCommander.Factions[factionId]
    if faction ~= nil then candidates = faction.AvailableUnits or {} end
  end

  local result = {}
  local seen = {}

  for _, id in ipairs(candidates) do
    if not seen[id] then
      seen[id] = true

      local banned = false
      if not ignoreFaction and MelonCommander.GameRules ~= nil and MelonCommander.GameRules.BannedUnits ~= nil then
        banned = MelonCommander.GameRules.BannedUnits[id] ~= nil
      end

      if not banned and V.IsFactoryUnit(id) and (anyUnit or memberCount[id] == 1) then
        table.insert(result, id)
      end
    end
  end

  table.sort(result, function(a, b)
    local ta, tb = MelonCommander.Units[a], MelonCommander.Units[b]
    if (ta.BuildCost or 0) ~= (tb.BuildCost or 0) then return (ta.BuildCost or 0) < (tb.BuildCost or 0) end

    return a < b
  end)

  return result
end
