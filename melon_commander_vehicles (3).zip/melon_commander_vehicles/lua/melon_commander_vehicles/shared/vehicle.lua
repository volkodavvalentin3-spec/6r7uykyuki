--[[
  Melon Commander: Garage - the vehicle unit.

  One unit template (Garage:Vehicle) and one component (Garage:VehicleBody) are enough for every
  vehicle in the game: the blueprint is attached to each entity instance (ent.VehicleDesign on the
  server, the NW2 string V.NWCode on the clients), so the body, speed and health are all per-vehicle.
]]--

local V = MelonCommander.Vehicles

local Base = MelonCommander.Expansions.Base

local body = MelonCommander.RegisterComponentTemplate(V.ComponentId)

local function getVitality(ent)
  return ent:GetComponentState(Base.Component.Vitality)
end

-- Server -------------------------------------------------------------------------------------------

body.ServerInitialize = function(ent, data)
  local design = ent.VehicleDesign
  local stats = ent.VehicleStats

  if design == nil or stats == nil then
    -- Spawned by something that doesn't know about blueprints (e.g. a console spawn) - give it a default body.
    design = V.NormalizeDesign(V.DefaultDesign())
    stats = V.ComputeStats(design)

    ent.VehicleDesign = design
    ent.VehicleStats = stats
  end

  local layout = V.ComputeLayout(design)

  data.Design = design
  data.Stats = stats
  data.Layout = layout

  -- The cargo bay is the base game's transport mechanism; without the module it is switched off.
  local transport = ent:GetComponentState(Base.Component.UnitTransport)
  if transport ~= nil and not stats.Cargo then
    transport.NextUse = math.huge
  end

  data.NextContact = 0
  data.NextAura = 0
  data.LastThink = CurTime()
  data.RamCooldowns = {}

  ent:SetModel(V.Models.Body)
  ent:SetNW2String(V.NWCode, V.EncodeCode(design))

  ent:PhysicsInitBox(layout.Mins, layout.Maxs, "ice")
  ent:SetMoveType(MOVETYPE_VPHYSICS)
  ent:SetSolid(SOLID_VPHYSICS)

  local physObject = ent:GetPhysicsObject()
  if IsValid(physObject) then
    physObject:Wake()
    physObject:SetDamping(1.5, 10)
  end

  constraint.Keepupright(ent, ent:GetAngles(), 0, 999999)

  construct.SetPhysProp(ent:GetOwner(), ent, 0, nil, {
    GravityToggle = true,
    Material = "ice"
  })

  if IsValid(physObject) then
    physObject:SetMass(V.Clamp(stats.Mass, 10, 50000))
  end

  -- Vitality is listed after this component, so it picks these values up in its own ServerInitialize.
  local vitality = getVitality(ent)
  if vitality ~= nil then
    vitality.MaxHealth = stats.Health
    vitality.InitialHealth = stats.Health
  end
end

-- Turn the hull towards its goal with angular velocity (SetAngles would tear the welded weapons off).
local function steer(ent, data)
  local unitState = ent:GetUnitState()
  if unitState == nil then return end

  local goal = unitState.CurrentRallyPoint
  if goal == nil then return end

  local physObject = ent:GetPhysicsObject()
  if not IsValid(physObject) or not physObject:IsMotionEnabled() then return end

  local direction = goal - ent:GetPos()
  direction.z = 0
  if direction:LengthSqr() < 400 then return end

  local desiredYaw = direction:Angle().y
  local currentYaw = ent:GetAngles().y + V.FrontYaw
  local difference = math.AngleDifference(desiredYaw, currentYaw)

  local turn = V.Clamp(difference * 4, -150, 150)

  local angVel = physObject:GetAngleVelocity()
  physObject:AddAngleVelocity(Vector(-angVel.x, -angVel.y, turn - angVel.z))
end

local function regenerate(ent, data, dt)
  local regen = data.Stats.Regen
  if regen <= 0 then return end

  local vitality = getVitality(ent)
  if vitality == nil then return end

  if ent:GetUnitHealth() >= vitality.MaxHealth then return end

  ent:CallComponents("Heal", { regen * dt })
end

local function healAura(ent, data, now)
  local stats = data.Stats
  if stats.HealAura <= 0 then return end
  if now < data.NextAura then return end

  data.NextAura = now + 1.0

  for _, v in ipairs(ents.FindInSphere(ent:GetPos(), stats.HealAuraRadius)) do
    if v ~= ent and MelonCommander.IsEntityUnit(v) and ent:IsAlly(v) then
      local template = v:GetUnitTemplate()
      local vitality = v:GetComponentState(Base.Component.Vitality)

      if template ~= nil and template.Healable and vitality ~= nil and v:GetUnitHealth() < vitality.MaxHealth then
        v:CallComponents("Heal", { stats.HealAura })
      end
    end
  end
end

local function contactDamage(ent, data, now)
  local stats = data.Stats
  if stats.ContactDamage <= 0 then return end
  if now < data.NextContact then return end

  data.NextContact = now + 0.4

  local speed = ent:GetVelocity():Length()
  if speed < 100 then return end

  local factor = V.Clamp(speed / (stats.Speed * 25), 0.5, 1.5)
  local radius = data.Layout.Radius + 12

  for _, v in ipairs(ents.FindInSphere(ent:GetPos(), radius)) do
    if v ~= ent and MelonCommander.IsEntityUnit(v) and not ent:IsAlly(v) and v:IsInGame() and v:IsFinishedBuilding() then
      local template = v:GetUnitTemplate()

      if template ~= nil and template.Targetable then
        v:TakeUnitDamage(stats.ContactDamage * factor, ent)

        if stats.Poison ~= nil then
          data.Poisoned = data.Poisoned or {}
          data.Poisoned[v] = CurTime() + stats.Poison.Duration
        end
      end
    end
  end
end

-- Vanilla kit: one emergency patch-up when the hull gets low.
local function emergencyRepair(ent, data, now)
  local repair = data.Stats.EmergencyRepair
  if repair == nil or now < (data.NextRepair or 0) then return end

  local vitality = getVitality(ent)
  if vitality == nil then return end

  local maxHealth = vitality.MaxHealth
  if ent:GetUnitHealth() > maxHealth * repair.Threshold then return end

  data.NextRepair = now + repair.Cooldown
  ent:CallComponents("Heal", { maxHealth * repair.Heal })

  local effect = EffectData()
  effect:SetOrigin(ent:GetPos() + Vector(0, 0, 20))
  effect:SetScale(1)
  util.Effect("StunstickImpact", effect)
  sound.Play("items/medshot4.wav", ent:GetPos(), 80, 100, 1)
end

-- Empire bastion: standing still digs the vehicle in (data.Sieged is read by the damage hook).
local function siegeMode(ent, data, now)
  local siege = data.Stats.Siege
  if siege == nil then return end

  if ent:GetVelocity():Length() > 25 then
    data.StillSince = nil
    data.Sieged = false
    return
  end

  data.StillSince = data.StillSince or now
  data.Sieged = now - data.StillSince >= siege.Delay

  if data.Sieged then
    local vitality = getVitality(ent)
    if vitality ~= nil and ent:GetUnitHealth() < vitality.MaxHealth then
      ent:CallComponents("Heal", { siege.Regen * 0.1 })
    end
  end
end

-- Falcon reactor: a periodic ion pulse that hits every enemy around the vehicle.
local function ionPulse(ent, data, now)
  local pulse = data.Stats.Pulse
  if pulse == nil then return end

  data.NextPulse = data.NextPulse or (now + pulse.Interval * 0.5)
  if now < data.NextPulse then return end

  local victims = {}
  for _, v in ipairs(ents.FindInSphere(ent:GetPos(), pulse.Radius)) do
    if v ~= ent and MelonCommander.IsEntityUnit(v) and not ent:IsAlly(v) and v:IsInGame() and v:IsFinishedBuilding() then
      local template = v:GetUnitTemplate()
      if template ~= nil and template.Targetable then table.insert(victims, v) end
    end
  end

  -- Nobody around: keep the charge until there is a target.
  if #victims == 0 then return end

  data.NextPulse = now + pulse.Interval

  local origin = ent:GetPos() + Vector(0, 0, 20)
  local effect = EffectData()
  effect:SetOrigin(origin)
  effect:SetScale(2)
  util.Effect("cball_explode", effect)
  sound.Play("ambient/energy/zap" .. tostring(math.random(1, 3)) .. ".wav", ent:GetPos(), 90, 100, 1)

  for _, v in ipairs(victims) do
    local hit = EffectData()
    hit:SetOrigin(v:GetPos() + Vector(0, 0, 20))
    hit:SetScale(1)
    util.Effect("cball_explode", hit)

    v:TakeUnitDamage(pulse.Damage, ent)
  end
end

-- Void spikes: poisoned enemies keep taking damage after the ram.
local function poisonTick(ent, data, now)
  local poison = data.Stats.Poison
  if poison == nil or data.Poisoned == nil then return end
  if now < (data.NextPoison or 0) then return end

  data.NextPoison = now + 1.0

  for victim, expires in pairs(data.Poisoned) do
    if not IsValid(victim) or not victim:IsInGame() or now >= expires then
      data.Poisoned[victim] = nil
    else
      victim:TakeUnitDamage(poison.Dps, ent)

      local effect = EffectData()
      effect:SetOrigin(victim:GetPos() + Vector(0, 0, 18))
      effect:SetScale(1)
      util.Effect("StunstickImpact", effect)
    end
  end
end

-- Mothership module: every now and then a mosquito drone pops out of the vehicle (free, they follow it around).
local function swarm(ent, data, now)
  local spawners = data.Stats.Spawners
  if spawners == nil or #spawners == 0 then return end

  data.Swarms = data.Swarms or {}

  local owner = ent:GetUnitOwner()
  local anchor = MelonCommander.Utility.Space.GetGroundPos(ent:GetPos())

  for index, spawner in ipairs(spawners) do
    local state = data.Swarms[index]
    if state == nil then
      state = { Next = now + (spawner.Interval or 20) * 0.5, Units = {} }
      data.Swarms[index] = state
    end

    local alive = {}
    for _, unit in ipairs(state.Units) do
      if IsValid(unit) then table.insert(alive, unit) end
    end
    state.Units = alive

    -- Drones that fell behind fly back to the carrier.
    for _, unit in ipairs(alive) do
      if unit:GetPos():Distance(anchor) > 900 then
        unit:SetRallyPoint(anchor)
        unit:SetUnitTarget(NULL)
      end
    end

    local template = MelonCommander.Units[spawner.Unit]

    if template ~= nil and #alive < (spawner.Max or 3) and now >= state.Next then
      state.Next = now + (spawner.Interval or 20)

      local unit = MelonCommander.CreateUnit(spawner.Unit)
      if IsValid(unit) then
        unit:SetUnitOwner(owner)
        unit:SetUnitIsTurret(false)
        unit:UpdateOwnerColor()
        unit:GetUnitState().instantBuild = true

        local spawnPos = ent:GetPos() + Vector(0, 0, data.Layout.Radius * 0.4 + 24)
        MelonCommander.AdjustPlacingUnit(unit, template, spawnPos, ent:GetAngles(), true)

        if IsValid(unit) then
          table.insert(state.Units, unit)
          sound.Play("doors/door_latch1.wav", ent:GetPos(), 70, 100, 1.0)
        end
      end
    end
  end
end

-- Kamikaze module: touching an enemy detonates the vehicle.
local function kamikaze(ent, data)
  local stats = data.Stats
  if stats.KamikazeDamage <= 0 or data.Exploded then return end

  local position = ent:GetPos()
  local touchRadius = data.Layout.Radius + 14
  local touched = false

  for _, v in ipairs(ents.FindInSphere(position, touchRadius)) do
    if v ~= ent and MelonCommander.IsEntityUnit(v) and not ent:IsAlly(v) and v:IsInGame()
        and v:IsFinishedBuilding() and not v:HasFlag(MelonCommander.UnitFlags.Air) then
      local template = v:GetUnitTemplate()
      if template ~= nil and template.Targetable then touched = true end
    end
  end

  if not touched then return end

  data.Exploded = true

  local radius = stats.KamikazeRadius
  local effect = EffectData()
  effect:SetOrigin(position)
  effect:SetScale(1)
  util.Effect("Explosion", effect)
  sound.Play("weapons/explode" .. tostring(math.random(3, 5)) .. ".wav", position, 100, 100, 1)

  for _, v in ipairs(ents.FindInSphere(position, radius)) do
    if v ~= ent and MelonCommander.IsEntityUnit(v) and not ent:IsAlly(v) and v:IsInGame() and v:IsFinishedBuilding() then
      local template = v:GetUnitTemplate()

      if template ~= nil and template.Targetable then
        local falloff = 1 - 0.6 * (v:GetPos():Distance(position) / radius)
        v:TakeUnitDamage(stats.KamikazeDamage * math.max(falloff, 0.4), ent)
      end
    end
  end

  ent:CallComponents("Die", { ent })
end

-- Mobile factory module: produces the chosen light unit behind the vehicle while it drives (costs half the unit's price).
local function factories(ent, data, now)
  local design = data.Design
  local unitId = design.Factory
  if unitId == nil or unitId == "" then return end

  local template = MelonCommander.Units[unitId]
  if template == nil then return end

  if data.Lines == nil then
    data.Lines = {}

    for _, id in ipairs(design.Modules) do
      local module = V.GetPart("Module", id)

      if module ~= nil and module.Factory ~= nil then
        table.insert(data.Lines, {
          Max = module.Factory.Max or 3,
          Interval = math.max((template.BuildTime or 10) * (module.Factory.IntervalMul or 0.6), module.Factory.MinInterval or 6),
          Next = now + 3,
          Units = {}
        })
      end
    end
  end

  local plyIdentifier = ent:GetUnitOwner()

  for _, line in ipairs(data.Lines) do
    local alive = {}
    for _, unit in ipairs(line.Units) do
      if IsValid(unit) then table.insert(alive, unit) end
    end
    line.Units = alive

    if #alive < line.Max and now >= line.Next then
      line.Next = now + line.Interval

      local unit = MelonCommander.PurchaseUnit(plyIdentifier, unitId, 0.5)

      if IsValid(unit) then
        unit:GetUnitState().instantBuild = true
        MelonCommander.ReplicatePlayers()

        local forward = Angle(0, ent:GetAngles().y + V.FrontYaw, 0):Forward()
        local spawnPos = ent:GetPos() - forward * (data.Layout.Length / 2 + 22) + Vector(0, 0, 18)

        MelonCommander.AdjustPlacingUnit(unit, template, spawnPos, ent:GetAngles(), true)

        if IsValid(unit) then
          local rally = MelonCommander.Utility.Space.GetGroundPos(spawnPos - forward * 50)
          unit:AddRallyPoint(rally)
          unit:ReplicateRallyPoints()

          table.insert(line.Units, unit)
          sound.Play("doors/door_latch1.wav", ent:GetPos(), 70, 100, 1.0)
        end
      end
    end
  end
end

body.ServerThink = function(ent, data)
  if not ent:IsFinishedBuilding() then return end

  local now = CurTime()
  local dt = now - data.LastThink
  data.LastThink = now

  local stats = data.Stats

  if stats.Income > 0 and not data.IncomeApplied then
    local ply = MelonCommander.Players[ent:GetUnitOwner()]
    if ply ~= nil then
      MelonCommander.IncreasePlayerIncome(ply, stats.Income)
      data.IncomeApplied = true
      data.IncomeOwner = ent:GetUnitOwner()
    end
  end

  steer(ent, data)
  regenerate(ent, data, dt)
  healAura(ent, data, now)
  contactDamage(ent, data, now)
  emergencyRepair(ent, data, now)
  siegeMode(ent, data, now)
  ionPulse(ent, data, now)
  poisonTick(ent, data, now)
  swarm(ent, data, now)
  factories(ent, data, now)
  kamikaze(ent, data)
end

body.ServerRemove = function(ent, data)
  if data.IncomeApplied then
    local ply = MelonCommander.Players[data.IncomeOwner]
    if ply ~= nil then
      MelonCommander.DecreasePlayerIncome(ply, data.Stats.Income)
    end

    data.IncomeApplied = false
  end

  -- The drones go down together with their carrier.
  if data.Swarms ~= nil then
    for _, state in ipairs(data.Swarms) do
      for _, unit in ipairs(state.Units) do
        if IsValid(unit) then unit:Remove() end
      end
    end

    data.Swarms = nil
  end

  -- Attached weapons go down together with the vehicle.
  ent.McvRemoving = true

  if ent.VehicleWeaponUnits ~= nil then
    for _, weapon in ipairs(ent.VehicleWeaponUnits) do
      if IsValid(weapon) then weapon:Remove() end
    end

    ent.VehicleWeaponUnits = nil
  end
end

body.OnOwnerChanged = function(ent, data, oldOwner, newOwner)
  if not data.IncomeApplied then return end

  local oldPly = MelonCommander.Players[data.IncomeOwner]
  if oldPly ~= nil then
    MelonCommander.DecreasePlayerIncome(oldPly, data.Stats.Income)
  end

  data.IncomeApplied = false
end

-- Client ---------------------------------------------------------------------------------------------

body.ClientThink = function(ent, data)
  if data.Visual == nil then
    local code = ent:GetNW2String(V.NWCode, "")
    if code == "" or code == data.LastCode then return end

    data.LastCode = code

    local design = V.DecodeCode(code)
    if design == nil then return end

    data.Design = design
    data.Visual = V.CreateVisual(design)

    local layout = data.Visual.Layout
    local padding = Vector(24, 24, 24)
    ent:SetRenderBounds(layout.Mins - padding, layout.Maxs + padding)

    local vitality = getVitality(ent)
    local stats = V.ComputeStats(design)
    if vitality ~= nil and stats ~= nil then
      vitality.MaxHealth = stats.Health
    end
  end

  V.UpdateEntityVisual(ent, data)
end

body.ClientRemove = function(ent, data)
  if data.Visual ~= nil then
    V.RemoveVisual(data.Visual)
    data.Visual = nil
  end
end

-- All visible parts are separate clientside models, the entity itself stays invisible.
body.Draw = function(ent, data) end

-- Unit template ----------------------------------------------------------------------------------------

local unit = MelonCommander.RegisterUnitTemplate(V.UnitId)

unit.DisplayName = "Custom vehicle"
unit.Description = [[
  A vehicle assembled in the Garage.
  Weapons are separate units bolted on its mounts.
]]

unit.Flags = {
  MelonCommander.UnitFlags.Ground,
  MelonCommander.UnitFlags.Weldable
}

unit.Category = MelonCommander.UnitCategory.Units

-- Vehicles are bought through the Garage tab (their price depends on the blueprint),
-- so the template itself is neither buildable nor part of any faction list.
unit.Buildable = false
unit.BuildCost = 0
unit.BuildTime = 0

unit.CanBeTurret = false
unit.SpawnOffset = Vector(0, 0, 0)
unit.SpawnRotation = -V.FrontYaw
unit.ShouldFaceMoveTarget = false
unit.ThinkDelay = 0.1

-- The real speed is written into the unit state when a vehicle is built.
unit.Locomotor = Base.Locomotor.RegularGround

unit.Components = {
  -- Listed before the body: the body switches it off in its own ServerInitialize if there is no cargo bay.
  MelonCommander.CreateComponent(Base.Component.UnitTransport, {
    AffectRadius = 110,
    UseDelay = 2.0,
    Cap = 6
  }),
  MelonCommander.CreateComponent(V.ComponentId, {}),
  MelonCommander.CreateComponent(Base.Component.Vitality, {
    MaxHealth = 100,
    DrawHealth = true,
    DeathFX = {
      Sounds = {
        "phx/epicmetal_hard1.wav",
        "phx/epicmetal_hard2.wav",
        "phx/epicmetal_hard3.wav",
        "phx/epicmetal_hard4.wav",
        "phx/epicmetal_hard5.wav",
        "phx/epicmetal_hard6.wav",
        "phx/epicmetal_hard7.wav"
      },
      Effect = MelonCommander.Utility.String.Decorate("metal_death"),
      EffectCount = 6,
      EffectInterval = 0.05,
      EffectRandomness = 20
    }
  })
}


-- The base transport would also swallow the weapons bolted on a vehicle: skip turrets for vehicles.
do
  local transport = MelonCommander.Components[Base.Component.UnitTransport]

  if transport ~= nil and not transport.McvPatched then
    local original = transport.GatherAffectedUnits

    transport.GatherAffectedUnits = function(ent, data)
      if not (MelonCommander.IsEntityUnit(ent) and ent:GetUnitIdentifier() == V.UnitId) then
        return original(ent, data)
      end

      local result = {}

      local cap = data.Cap or 0
      local radius = data.AffectRadius or 250.0

      for _, v in ipairs(ents.FindByClass("ent_melon_commander_unit")) do
        if v ~= ent and MelonCommander.IsEntityUnit(v) and v:IsFinishedBuilding() and v:IsInGame()
            and v:GetUnitOwner() == ent:GetUnitOwner()
            and not v:GetUnitIsTurret()
            and not v:HasFlag(MelonCommander.UnitFlags.Building)
            and not v:HasFlag(MelonCommander.UnitFlags.Prop) then
          local template = v:GetUnitTemplate()

          if template ~= nil and template.Transportable and ent:GetPos():Distance(v:GetPos()) <= radius then
            table.insert(result, v)

            if cap > 0 and #result >= cap then break end
          end
        end
      end

      return result
    end

    transport.McvPatched = true
  end
end
