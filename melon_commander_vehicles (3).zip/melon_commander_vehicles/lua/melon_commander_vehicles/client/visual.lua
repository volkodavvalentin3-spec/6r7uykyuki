--[[
  Melon Commander: Garage - clientside visuals.

  A vehicle's looks are NOT networked entities: every hull plate, wheel, engine block and decoration
  is a ClientsideModel that is positioned from the vehicle's entity every frame. That's why a vehicle with
  dozens of parts costs the server exactly one entity (plus the weapon units that are bolted on it).

  Primitives (cube/sphere/cylinder/cone) are auto-fitted to the requested size from their model bounds,
  wheels are auto-fitted to the wheel radius and their spin axis is detected from the model (the
  thinnest direction of a disc), so any wheel model works without knowing its orientation.
]]--

local V = MelonCommander.Vehicles

local FLAT_MATERIAL = "models/debug/debugwhite"
local WIRE_MATERIAL = "models/wireframe"
local RAD_TO_DEG = 57.2957795

-- Rotation that maps the wheel model's spin axis (index = model axis x/y/z) onto the vehicle's left axis.
local wheelFixAngles = {
  Angle(0, 90, 0),
  Angle(0, 0, 0),
  Angle(0, 0, -90)
}

local function shapeModel(shape)
  if shape == "sphere" then return V.Models.Sphere end
  if shape == "cylinder" then return V.Models.Cylinder end
  if shape == "cone" then return V.Models.Cone end

  return V.Models.Cube
end

local function validModel(path)
  if path ~= nil and util.IsValidModel(path) then return path end

  return V.Models.Fallback
end

local function newClientModel(path, ghost, manual)
  local group = RENDERGROUP_OPAQUE
  if ghost then group = RENDERGROUP_TRANSLUCENT end

  local model = ClientsideModel(path, group)
  if not IsValid(model) then return nil end

  -- Manual models are drawn by V.DrawVisual (inside a cam.Start3D of a vgui preview), never by the world pass.
  model:SetNoDraw(manual == true)
  model:SetRenderMode(RENDERMODE_TRANSCOLOR)

  return model
end

local function safe(x)
  if x < 0.01 then return 0.01 end

  return x
end

local function createPrimitive(def, ghost, manual)
  local model = newClientModel(validModel(shapeModel(def.Shape)), ghost, manual)
  if model == nil then return nil end

  local mins, maxs = model:GetModelBounds()
  local extent = maxs - mins

  local sx = def.Size.x / safe(extent.x)
  local sy = def.Size.y / safe(extent.y)
  local sz = def.Size.z / safe(extent.z)

  local scaleMatrix = Matrix()
  scaleMatrix:Scale(Vector(sx, sy, sz))
  model:EnableMatrix("RenderMultiply", scaleMatrix)

  local pad = Vector(8, 8, 8)
  model:SetRenderBounds(
    Vector(mins.x * sx, mins.y * sy, mins.z * sz) - pad,
    Vector(maxs.x * sx, maxs.y * sy, maxs.z * sz) + pad
  )

  local center = (mins + maxs) * 0.5

  return {
    Ent = model,
    Kind = "primitive",
    Manual = manual == true,
    Pos = def.Pos,
    CenterOffset = Vector(center.x * sx, center.y * sy, center.z * sz),
    Color = def.Color,
    Tint = def.Tint,
    Material = FLAT_MATERIAL
  }
end

local function createWheel(wheelDef, wheelLayout, ghost, manual)
  local model = newClientModel(validModel(wheelDef.Model), ghost, manual)
  if model == nil then return nil end

  local mins, maxs = model:GetModelBounds()
  local extent = maxs - mins
  local sizes = { extent.x, extent.y, extent.z }

  local smallest, largest = math.min(sizes[1], sizes[2], sizes[3]), math.max(sizes[1], sizes[2], sizes[3])

  -- A wheel is a disc: the thinnest direction is its axle. Round-ish models just use the model's Y axis.
  local axis = 2
  if largest > 0 and smallest / largest < 0.85 then
    for i = 1, 3 do
      if sizes[i] == smallest then
        axis = i
        break
      end
    end
  end

  local diameter = 0
  for i = 1, 3 do
    if i ~= axis and sizes[i] > diameter then diameter = sizes[i] end
  end

  local scale = (wheelLayout.Radius * 2) / safe(diameter)
  model:SetModelScale(scale, 0)

  local pad = Vector(8, 8, 8)
  model:SetRenderBounds(mins * scale - pad, maxs * scale + pad)

  local center = (mins + maxs) * (0.5 * scale)

  return {
    Ent = model,
    Kind = "wheel",
    Manual = manual == true,
    Pos = wheelLayout.Pos,
    CenterOffset = center,
    Fix = wheelFixAngles[axis],
    Material = ""
  }
end

--[[
  Builds all clientside parts of a design. ghost = translucent preview used while placing,
  manual = the parts are only drawn by V.DrawVisual (used by the 3D preview in the Garage tab).
  Returns a visual table; give it to UpdateVisual every frame and to RemoveVisual when done.
]]--
function V.CreateVisual(design, ghost, manual)
  local layout = V.ComputeLayout(design)
  local wheelDef = V.GetPart("Wheel", design.Wheel)

  local visual = {
    Layout = layout,
    Parts = {},
    Spin = 0,
    WheelRadius = layout.WheelRadius,
    Ghost = ghost == true,
    Manual = manual == true
  }

  for _, def in ipairs(layout.Visuals) do
    local part = createPrimitive(def, ghost, manual)
    if part ~= nil then table.insert(visual.Parts, part) end
  end

  for _, wheelLayout in ipairs(layout.Wheels) do
    local part = createWheel(wheelDef, wheelLayout, ghost, manual)
    if part ~= nil then table.insert(visual.Parts, part) end
  end

  return visual
end

function V.RemoveVisual(visual)
  if visual == nil then return end

  for _, part in ipairs(visual.Parts) do
    if IsValid(part.Ent) then part.Ent:Remove() end
  end

  visual.Parts = {}
end

-- Vehicle frame angles: x axis = the direction the vehicle drives in.
local function frameAngles(entityAngles)
  local frame = Angle(entityAngles.p, entityAngles.y, entityAngles.r)
  frame:RotateAroundAxis(frame:Up(), V.FrontYaw)

  return frame
end

V.FrameAngles = frameAngles

local function setPartColor(part, r, g, b, a)
  r, g, b, a = math.floor(r), math.floor(g), math.floor(b), math.floor(a)

  if part.LastR == r and part.LastG == g and part.LastB == b and part.LastA == a then return end

  part.LastR, part.LastG, part.LastB, part.LastA = r, g, b, a
  part.Ent:SetColor(Color(r, g, b, a))
end

--[[
  origin / entityAngles - the unit entity's position and angles
  color - the unit's colour (owner colour already darkened by damage)
  forwardSpeed - speed along the driving direction in units per second (wheels spin with it)
  mode - "normal", "building" (wireframe), "ghost" (wireframe preview) or "hidden"
]]--
function V.UpdateVisual(visual, origin, entityAngles, color, forwardSpeed, dt, mode)
  local hidden = (mode == "hidden")
  local wire = (mode == "building" or mode == "ghost")

  local frame = frameAngles(entityAngles)

  local left = Vector(0, 1, 0)
  left:Rotate(frame)

  visual.Spin = (visual.Spin + forwardSpeed * dt / visual.WheelRadius * RAD_TO_DEG) % 360

  local r, g, b, a = color.r, color.g, color.b, color.a

  for _, part in ipairs(visual.Parts) do
    local model = part.Ent

    if IsValid(model) then
      if part.Hidden ~= hidden then
        part.Hidden = hidden
        if not part.Manual then model:SetNoDraw(hidden) end
      end

      if not hidden then
        local material = part.Material
        if wire then material = WIRE_MATERIAL end

        if part.LastMaterial ~= material then
          part.LastMaterial = material
          model:SetMaterial(material)
        end

        if part.Kind == "primitive" then
          if wire or part.Color == nil then
            local tint = part.Tint or 1
            setPartColor(part, r * tint, g * tint, b * tint, a)
          else
            setPartColor(part, part.Color.r, part.Color.g, part.Color.b, a)
          end

          local offset = Vector(
            part.Pos.x - part.CenterOffset.x,
            part.Pos.y - part.CenterOffset.y,
            part.Pos.z - part.CenterOffset.z
          )
          offset:Rotate(frame)

          model:SetPos(origin + offset)
          model:SetAngles(frame)
        else
          if wire then
            setPartColor(part, r, g, b, a)
          else
            setPartColor(part, 255, 255, 255, a)
          end

          local _, wheelAngles = LocalToWorld(Vector(0, 0, 0), part.Fix, Vector(0, 0, 0), frame)
          wheelAngles:RotateAroundAxis(left, visual.Spin)

          local centerOffset = Vector(part.CenterOffset.x, part.CenterOffset.y, part.CenterOffset.z)
          centerOffset:Rotate(wheelAngles)

          local wheelPos = Vector(part.Pos.x, part.Pos.y, part.Pos.z)
          wheelPos:Rotate(frame)

          model:SetPos(origin + wheelPos - centerOffset)
          model:SetAngles(wheelAngles)
        end
      end
    end
  end
end

-- Draws the parts of a manual visual (call it between cam.Start3D / cam.End3D).
function V.DrawVisual(visual)
  for _, part in ipairs(visual.Parts) do
    local model = part.Ent

    if IsValid(model) and not part.Hidden then
      model:SetupBones()
      model:DrawModel()
    end
  end
end

-- Drives UpdateVisual from a vehicle entity (called by the VehicleBody component every frame).
function V.UpdateEntityVisual(ent, data)
  local visual = data.Visual
  if visual == nil then return end

  local mode = "normal"
  if ent:IsDormant() or ent:GetNoDraw() then
    mode = "hidden"
  elseif not ent:IsFinishedBuilding() then
    mode = "building"
  end

  local angles = ent:GetAngles()
  local forward = frameAngles(angles):Forward()

  V.UpdateVisual(
    visual,
    ent:GetPos(),
    angles,
    ent:GetColor(),
    ent:GetVelocity():Dot(forward),
    FrameTime(),
    mode
  )
end
