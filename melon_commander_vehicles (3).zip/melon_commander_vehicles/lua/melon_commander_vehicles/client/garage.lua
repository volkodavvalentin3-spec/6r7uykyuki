--[[
  Melon Commander: Garage - clientside UI.

  - "Garage" tab in the command panel (the one that opens with Reload): pick hull, wheels, engine, armor,
    modules, decorations and the weapon units for every mount, with a rotating 3D preview and live stats.
  - "PlaceVehicle" player intent: a wireframe ghost of the vehicle follows the crosshair, left click builds it.
]]--

local V = MelonCommander.Vehicles

-- Texts --------------------------------------------------------------------------------------------------------

local function T(ru, en)
  return { ru = ru, en = en }
end

local UI = {
  Tab = T("Гараж", "Garage"),
  Preset = T("Готовая сборка", "Preset"),
  PresetHint = T("— выбрать —", "— choose —"),
  Name = T("Название", "Name"),
  Hull = T("Корпус", "Hull"),
  Wheel = T("Колёса", "Wheels"),
  Axles = T("Пар колёс", "Wheel pairs"),
  Engine = T("Двигатель", "Engine"),
  Armor = T("Броня", "Armor"),
  Module = T("Модуль", "Module"),
  Decor = T("Декор", "Decoration"),
  Weapon = T("Оружие (юнит)", "Weapon (unit)"),
  Mount = T("Крепление", "Mount"),
  Empty = T("— пусто —", "— empty —"),
  None = T("— нет —", "— none —"),
  Build = T("Построить машину", "Build vehicle"),
  Cost = T("Цена", "Cost"),
  Water = T("воды", "water"),
  Parts = T("детали", "parts"),
  Weapons = T("оружие", "weapons"),
  Health = T("Прочность", "Health"),
  Speed = T("Скорость", "Speed"),
  Mass = T("Масса", "Mass"),
  Damage = T("Получаемый урон", "Damage taken"),
  Regen = T("Ремонт", "Repair"),
  Contact = T("Таран", "Ramming"),
  Aura = T("Лечение рядом", "Heal aura"),
  Income = T("Доход воды", "Water income"),
  Swarm = T("Рой москитов (до)", "Mosquito swarm (up to)"),
  Guns = T("Доп. пулемётов", "Extra machine guns"),
  Cargo = T("Десант", "Passengers"),
  Kamikaze = T("Взрыв при столкновении", "Blast on impact"),
  Repair = T("Аварийный ремонт", "Emergency repair"),
  Siege = T("Осадный режим (урон)", "Siege mode (damage)"),
  Pulse = T("Ионный импульс", "Ion pulse"),
  Poison = T("Яд (урон/с x время)", "Poison (dps x time)"),
  SecShort = T("с", "s"),
  FactoryLines = T("Заводов", "Factories"),
  FactoryUnit = T("Юнит завода", "Factory unit"),
  BuildTime = T("Время сборки", "Build time"),
  PartCount = T("Деталей", "Parts"),
  Seconds = T("с", "s"),
  Each = T("за шт.", "each"),
  Light = T("лёгкое", "light"),
  Medium = T("среднее", "medium"),
  Heavy = T("тяжёлое", "heavy"),
  NotEnough = T("Не хватает воды", "Not enough water"),
  Language = T("Язык", "Language"),
  LangAuto = T("Авто (как в игре)", "Auto (follow the game)"),
  SizeBonus = T("Бонус размера", "Size bonus"),
  Hint = T(
    "Оружие — это обычные юниты, прикреплённые к креплениям. Колёса шоссе — самые быстрые.",
    "Weapons are normal units bolted on the mounts. Highway wheels are the fastest."
  )
}

local function text(key)
  return V.Text(UI[key])
end

local classNames = { "Light", "Medium", "Heavy" }

local function className(c)
  return text(classNames[c] or "Heavy")
end

-- Presets --------------------------------------------------------------------------------------------------------

local presets = {
  {
    Name = T("Шоссейный гонщик", "Highway racer"),
    Design = {
      Hull = "racer", Wheel = "highway", Axles = 2, Engine = "v6", Armor = "",
      Modules = { "nitro", "suspension" },
      Decor = { "spoiler", "lights", "exhaust" },
      Weapons = { "Base:Gunner" }
    }
  },
  {
    Name = T("Багги с пулемётом", "Gun buggy"),
    Design = {
      Hull = "buggy", Wheel = "light", Axles = 2, Engine = "i4", Armor = "sheet",
      Modules = { "repair" },
      Decor = { "antenna", "lights" },
      Weapons = { "Base:Gunner", "Base:Marine" }
    }
  },
  {
    Name = T("Техничка", "Technical"),
    Design = {
      Hull = "pickup", Wheel = "truck", Axles = 2, Engine = "v6", Armor = "steel",
      Modules = { "ram", "repair" },
      Decor = { "flag", "rack" },
      Weapons = { "Base:Gunner", "Base:Marine", "Base:Marine" }
    }
  },
  {
    Name = T("Миномётный грузовик", "Mortar truck"),
    Design = {
      Hull = "truck", Wheel = "bigtruck", Axles = 3, Engine = "diesel", Armor = "steel",
      Modules = { "repair", "shield" },
      Decor = { "antenna", "siren" },
      Weapons = { "Base:Mortar", "Base:Mortar", "Base:Gunner", "Base:Gunner" }
    }
  },
  {
    Name = T("Бронетранспортёр", "Armored carrier"),
    Design = {
      Hull = "apc", Wheel = "armored", Axles = 3, Engine = "diesel", Armor = "composite",
      Modules = { "shield", "medic", "repair", "ram" },
      Decor = { "searchlight", "antenna" },
      Weapons = { "Base:Gunner", "Base:Marine", "Base:Marine", "Base:Missile" }
    }
  },
  {
    Name = T("Сухопутный линкор", "Land battleship"),
    Design = {
      Hull = "mega", Wheel = "tractor", Axles = 5, Engine = "melonium", Armor = "rind",
      Modules = { "nano", "shield", "medic", "ram", "spikes", "plating", "cage", "collector" },
      Decor = { "flag", "searchlight", "siren", "antenna", "melon", "exhaust" },
      Weapons = { "Base:Missile", "Base:Missile", "Base:Mortar", "Base:Gunner", "Base:Gunner", "Base:Marine", "Base:Marine", "Base:Flak" }
    }
  }
}

V.Presets = presets

-- Helpers ----------------------------------------------------------------------------------------------------------

local function localFaction()
  local ply = MelonCommander.GetLocalPlayer()
  if ply == nil then return "" end

  return ply.Faction
end

local function weaponContext()
  local allowed = {}
  for _, id in ipairs(V.GetAvailableWeapons(localFaction())) do
    allowed[id] = true
  end

  return {
    FactionId = localFaction(),
    IsWeaponAllowed = function(id) return allowed[id] == true end
  }
end

local function firstWheelFor(hull)
  for _, id in ipairs(V.PartOrder.Wheel) do
    local wheel = V.GetPart("Wheel", id)
    if wheel.Radius <= V.MaxWheelRadius(hull) then return id end
  end

  return V.PartOrder.Wheel[1]
end

local function saveDesign(design)
  local ok = pcall(function()
    cookie.Set("melon_commander_vehicles_design", util.TableToJSON(design))
  end)

  return ok
end

local function loadDesign()
  local json = cookie.GetString("melon_commander_vehicles_design", "")
  if json ~= "" then
    local raw = util.JSONToTable(json)
    if raw ~= nil then
      -- Weapons that are no longer valid just get dropped by the garage later on.
      local design = V.NormalizeDesign(raw)
      if design ~= nil then return design end
    end
  end

  return V.NormalizeDesign(V.DefaultDesign())
end

local function fontOr(name, fallback)
  return name or fallback
end

local colorHint = Color(143, 143, 143)
local borderColor = Color(55, 55, 55)
local bodyColor = Color(30, 30, 30, 230)
local errorColor = Color(255, 110, 90)
local okColor = Color(120, 230, 120)

local function paintButton(button, w, h)
  if button:GetDisabled() then
    draw.RoundedBox(8, 0, 0, w, h, Color(180, 180, 180))
    return
  end

  if button:IsHovered() then
    button:SetColor(Color(70, 70, 70))
  else
    button:SetColor(color_black)
  end

  draw.RoundedBox(8, 0, 0, w, h, color_white)
end

local function paintTab(tab, w, h)
  if tab:IsActive() then
    surface.SetDrawColor(color_white)
    surface.DrawLine(0, h - 1, w, h - 1)
  end
end

-- Garage tab -------------------------------------------------------------------------------------------------------

local function buildGarageTab(gameplayPanel)
  if gameplayPanel.tabs == nil then return end

  local state = loadDesign()

  local moduleSlots = {}
  local decorSlots = {}

  local visual = nil
  local visualCode = nil
  local refreshing = false
  local factorySignature = nil

  local root = vgui.Create("DPanel")
  root.Paint = function() end

  -- Right column: preview, stats, build button ------------------------------------------------------------------------

  local right = vgui.Create("DPanel", root)
  right:SetWide(240)
  right:Dock(RIGHT)
  right:DockMargin(8, 8, 0, 8)
  right.Paint = function() end

  local preview = vgui.Create("DPanel", right)
  preview:SetTall(170)
  preview:Dock(TOP)

  preview.Paint = function(panel, w, h)
    draw.RoundedBox(8, 0, 0, w, h, borderColor)
    draw.RoundedBox(8, 1, 1, w - 2, h - 2, Color(22, 22, 24, 255))

    if visual == nil then return end

    local layout = visual.Layout
    local ply = MelonCommander.GetLocalPlayer()
    local color = Color(200, 200, 200)
    if ply ~= nil and ply.Color ~= nil then color = ply.Color end

    local yaw = (CurTime() * 26) % 360
    V.UpdateVisual(visual, Vector(0, 0, 0), Angle(0, yaw - V.FrontYaw, 0), color, 55, FrameTime(), "normal")

    local x, y = panel:LocalToScreen(0, 0)

    local target = Vector(0, 0, -layout.Clearance * 0.45)
    local distance = layout.Radius * 2.5 + 28
    local camPos = target + Vector(distance * 0.85, distance * 0.55, distance * 0.42)
    local camAng = (target - camPos):Angle()

    cam.Start3D(camPos, camAng, 32, x + 1, y + 1, w - 2, h - 2, 4, 4096)
      render.SuppressEngineLighting(true)
      render.SetLightingOrigin(Vector(0, 0, 0))
      render.ResetModelLighting(0.45, 0.45, 0.45)
      render.SetModelLighting(BOX_TOP, 1.0, 1.0, 1.0)
      render.SetModelLighting(BOX_FRONT, 0.75, 0.75, 0.75)
      render.SetModelLighting(BOX_RIGHT, 0.6, 0.6, 0.6)

      V.DrawVisual(visual)

      render.SuppressEngineLighting(false)
    cam.End3D()
  end

  local statsLabel = vgui.Create("DLabel", right)
  statsLabel:SetFont(MelonCommander.FontRegular)
  statsLabel:SetColor(color_white)
  statsLabel:SetWrap(true)
  statsLabel:SetAutoStretchVertical(true)
  statsLabel:DockMargin(2, 8, 0, 0)
  statsLabel:Dock(TOP)

  local messageLabel = vgui.Create("DLabel", right)
  messageLabel:SetFont(MelonCommander.FontWeak)
  messageLabel:SetColor(colorHint)
  messageLabel:SetWrap(true)
  messageLabel:SetAutoStretchVertical(true)
  messageLabel:DockMargin(2, 6, 0, 0)
  messageLabel:Dock(TOP)

  local buildButton = vgui.Create("DButton", right)
  buildButton:SetMinimumSize(nil, 34)
  buildButton:SetTall(34)
  buildButton:SetFont(MelonCommander.FontRegular)
  buildButton:SetText(text("Build"))
  buildButton:Dock(BOTTOM)
  buildButton.Paint = paintButton

  -- Left column: part pickers ------------------------------------------------------------------------------------------

  local left = vgui.Create("DScrollPanel", root)
  left:Dock(FILL)
  left:DockMargin(0, 8, 0, 8)

  local function addLabel(parent, caption)
    local label = vgui.Create("DLabel", parent)
    label:SetFont(MelonCommander.FontWeak)
    label:SetColor(colorHint)
    label:SetText(caption)
    label:SetTall(16)
    label:DockMargin(2, 6, 0, 0)
    label:Dock(TOP)

    return label
  end

  local function addCombo(parent)
    local combo = vgui.Create("DComboBox", parent)
    combo:SetTall(22)
    combo:SetSortItems(false)
    combo:DockMargin(0, 2, 8, 0)
    combo:Dock(TOP)

    return combo
  end

  local function fillCombo(combo, items, currentId, placeholder)
    combo:Clear()

    local selected = false
    for _, item in ipairs(items) do
      local isSelected = (item.Id == currentId)
      if isSelected then selected = true end

      combo:AddChoice(item.Text, item.Id, isSelected)
    end

    if not selected then
      combo:SetValue(placeholder or "")
    end
  end

  -- Language
  addLabel(left, text("Language"))
  local langCombo = addCombo(left)

  local langConVar = GetConVar("melon_commander_vehicles_lang")
  fillCombo(langCombo, {
    { Id = "auto", Text = text("LangAuto") },
    { Id = "ru", Text = "Русский" },
    { Id = "en", Text = "English" }
  }, langConVar ~= nil and langConVar:GetString() or "auto")

  langCombo.OnSelect = function(_, _, _, id)
    if refreshing or id == nil then return end

    if langConVar ~= nil then langConVar:SetString(id) end

    -- Every text of the Garage tab is baked in when it is built, so build it again in the new language.
    timer.Simple(0, function()
      if V.RebuildGarageUI ~= nil then V.RebuildGarageUI(gameplayPanel) end
    end)
  end

  -- Preset
  addLabel(left, text("Preset"))
  local presetCombo = addCombo(left)

  -- Name
  addLabel(left, text("Name"))
  local nameEntry = vgui.Create("DTextEntry", left)
  nameEntry:SetTall(22)
  nameEntry:SetUpdateOnType(true)
  nameEntry:DockMargin(0, 2, 8, 0)
  nameEntry:Dock(TOP)

  -- Hull
  addLabel(left, text("Hull"))
  local hullCombo = addCombo(left)

  -- Wheels
  addLabel(left, text("Wheel"))
  local wheelCombo = addCombo(left)

  addLabel(left, text("Axles"))
  local axlesSlider = vgui.Create("DNumSlider", left)
  axlesSlider:SetTall(22)
  axlesSlider:SetDecimals(0)
  axlesSlider:SetMinMax(1, 2)
  axlesSlider:SetValue(2)
  axlesSlider:DockMargin(0, 0, 8, 0)
  axlesSlider:Dock(TOP)
  axlesSlider.Label:SetVisible(false)
  axlesSlider.TextArea:SetTextColor(color_white)

  -- Engine
  addLabel(left, text("Engine"))
  local engineCombo = addCombo(left)

  -- Armor
  addLabel(left, text("Armor"))
  local armorCombo = addCombo(left)

  -- Unit that mobile factory modules produce (shown only when the design has one)
  local factoryLabel = addLabel(left, text("FactoryUnit"))
  local factoryCombo = addCombo(left)
  factoryLabel:SetVisible(false)
  factoryCombo:SetVisible(false)

  -- Dynamic slots (rebuilt whenever the hull changes)
  local dynamic = vgui.Create("DPanel", left)
  dynamic.Paint = function() end
  dynamic:DockMargin(0, 0, 0, 0)
  dynamic:Dock(TOP)

  -- Logic ----------------------------------------------------------------------------------------------------------

  local refresh

  local function currentHull()
    return V.GetPart("Hull", state.Hull)
  end

  local function compactSlots(slots, count)
    local list = {}
    for i = 1, count do
      local id = slots[i]
      if id ~= nil and id ~= "" then table.insert(list, id) end
    end

    return list
  end

  local function partItems(slot)
    local items = {}

    for _, id in ipairs(V.PartOrder[slot]) do
      local part = V.GetPart(slot, id)
      if slot ~= "Module" or V.ModuleAllowed(part, localFaction()) then
        table.insert(items, { Id = id, Text = V.Text(part.Name) .. "  (" .. tostring(part.Cost) .. ")" })
      end
    end

    return items
  end

  local function wheelItems(hull)
    local items = {}

    for _, id in ipairs(V.PartOrder.Wheel) do
      local wheel = V.GetPart("Wheel", id)

      if wheel.Radius <= V.MaxWheelRadius(hull) then
        table.insert(items, { Id = id, Text = V.Text(wheel.Name) .. "  (" .. tostring(wheel.Cost) .. " x2)" })
      end
    end

    return items
  end

  local function rebuildDynamic()
    dynamic:Clear()

    local hull = currentHull()
    if hull == nil then return end

    moduleSlots = {}
    decorSlots = {}

    -- Drop faction modules that this player's faction cannot use (e.g. after switching faction).
    local keptModules = {}
    for _, id in ipairs(state.Modules) do
      if V.ModuleAllowed(V.GetPart("Module", id), localFaction()) then table.insert(keptModules, id) end
    end
    state.Modules = keptModules

    for i, id in ipairs(state.Modules) do moduleSlots[i] = id end
    for i, id in ipairs(state.Decor) do decorSlots[i] = id end

    local height = 0

    local function addRow(caption, items, current, onSelect)
      local label = addLabel(dynamic, caption)
      local combo = addCombo(dynamic)

      local entries = { { Id = "", Text = text("Empty") } }
      for _, item in ipairs(items) do table.insert(entries, item) end

      fillCombo(combo, entries, current or "", text("Empty"))

      combo.OnSelect = function(_, _, _, data)
        if refreshing then return end

        onSelect(data or "")
        refresh()
      end

      height = height + label:GetTall() + 6 + combo:GetTall() + 2
    end

    local moduleItems = partItems("Module")
    local moduleCount = V.ModuleSlotCount(hull)
    for i = 1, moduleCount do
      addRow(text("Module") .. " " .. tostring(i), moduleItems, moduleSlots[i], function(id)
        moduleSlots[i] = id
        state.Modules = compactSlots(moduleSlots, moduleCount)
      end)
    end

    local decorItems = partItems("Decor")
    local decorCount = V.DecorSlotCount(hull)
    for i = 1, decorCount do
      addRow(text("Decor") .. " " .. tostring(i), decorItems, decorSlots[i], function(id)
        decorSlots[i] = id
        state.Decor = compactSlots(decorSlots, decorCount)
      end)
    end

    for i, mount in ipairs(hull.Mounts) do
      local items = {}

      for _, id in ipairs(V.GetAvailableWeapons(localFaction(), V.MountMaxClass(mount))) do
        table.insert(items, { Id = id, Text = V.WeaponName(id) .. "  (" .. tostring(V.WeaponCost(id)) .. ")" })
      end

      local caption = text("Mount") .. " " .. tostring(i) .. " [" .. className(mount.c) .. "]"
      addRow(caption, items, state.Weapons[i], function(id)
        state.Weapons[i] = id
      end)
    end

    dynamic:SetTall(height + 8)
    dynamic:InvalidateLayout(true)
    left:InvalidateLayout(true)
  end

  -- Brings every part of the blueprint into agreement with the chosen hull.
  local function adjustToHull()
    local hull = currentHull()
    if hull == nil then return end

    local wheel = V.GetPart("Wheel", state.Wheel)
    if wheel == nil or wheel.Radius > V.MaxWheelRadius(hull) then
      state.Wheel = firstWheelFor(hull)
    end

    state.Axles = V.Clamp(state.Axles or 1, hull.MinAxles or 1, V.MaxAxles(hull))

    while #state.Modules > V.ModuleSlotCount(hull) do table.remove(state.Modules) end
    while #state.Decor > V.DecorSlotCount(hull) do table.remove(state.Decor) end

    local oldWeapons = state.Weapons or {}
    state.Weapons = {}

    for i, mount in ipairs(hull.Mounts) do
      local id = oldWeapons[i] or ""

      if id ~= "" and (not V.IsWeaponUnit(id) or not V.MountAccepts(mount, id)) then
        id = ""
      end

      state.Weapons[i] = id
    end
  end

  local function syncControls()
    refreshing = true

    local hull = currentHull()

    fillCombo(hullCombo, partItems("Hull"), state.Hull)
    fillCombo(wheelCombo, wheelItems(hull), state.Wheel)

    axlesSlider:SetMinMax(hull.MinAxles or 1, V.MaxAxles(hull))
    axlesSlider:SetValue(state.Axles)

    fillCombo(engineCombo, partItems("Engine"), state.Engine)

    local armorItems = { { Id = "", Text = text("None") } }
    for _, item in ipairs(partItems("Armor")) do table.insert(armorItems, item) end
    fillCombo(armorCombo, armorItems, state.Armor or "", text("None"))

    nameEntry:SetValue(state.Name or "")

    rebuildDynamic()

    refreshing = false
  end

  local function costLine(label, value)
    return label .. ": " .. value
  end

  refresh = function()
    local design, err = V.NormalizeDesign(state, weaponContext())

    if design == nil then
      messageLabel:SetColor(errorColor)
      messageLabel:SetText(tostring(err))
      buildButton:SetDisabled(true)

      return
    end

    local stats = V.ComputeStats(design)

    -- Mobile factory unit picker
    local factoryVisible = stats.FactoryCount > 0
    if factoryLabel:IsVisible() ~= factoryVisible then
      factoryLabel:SetVisible(factoryVisible)
      factoryCombo:SetVisible(factoryVisible)
      left:InvalidateLayout(true)
    end

    if factoryVisible then
      state.Factory = design.Factory

      local items = {}
      for _, id in ipairs(V.GetFactoryUnits(localFaction())) do
        table.insert(items, { Id = id, Text = V.WeaponName(id) .. "  (" .. tostring(math.floor((MelonCommander.Units[id].BuildCost or 0) * 0.5)) .. "/" .. text("Each") .. ")" })
      end

      local signature = table.concat((function() local ids = {} for _, item in ipairs(items) do table.insert(ids, item.Id) end return ids end)(), ",") .. "|" .. design.Factory
      if factorySignature ~= signature then
        factorySignature = signature

        local wasRefreshing = refreshing
        refreshing = true
        fillCombo(factoryCombo, items, design.Factory)
        refreshing = wasRefreshing
      end
    end

    local code = V.EncodeCode(design)
    if visual == nil or visualCode ~= code then
      if visual ~= nil then V.RemoveVisual(visual) end

      visual = V.CreateVisual(design, false, true)
      visualCode = code
    end

    local ply = MelonCommander.GetLocalPlayer()
    local water = ply ~= nil and ply.Water or 0

    local lines = {}
    table.insert(lines, text("Cost") .. ": " .. tostring(stats.Cost) .. " " .. text("Water")
      .. "  (" .. text("Parts") .. " " .. tostring(stats.PartsCost) .. " + " .. text("Weapons") .. " " .. tostring(stats.WeaponsCost) .. ")")
    table.insert(lines, text("Health") .. ": " .. tostring(stats.Health))
    table.insert(lines, text("Speed") .. ": " .. string.format("%.1f", stats.Speed)
      .. "  (" .. text("SizeBonus") .. " " .. string.format("%+d%%", math.floor((stats.SizeMul - 1) * 100 + 0.5)) .. ")")
    table.insert(lines, text("Mass") .. ": " .. tostring(math.floor(stats.Mass)))

    if stats.DamageMult < 1 then
      table.insert(lines, text("Damage") .. ": " .. string.format("%d%%", math.floor(stats.DamageMult * 100 + 0.5)))
    end

    if stats.Regen > 0 then
      table.insert(lines, text("Regen") .. ": " .. string.format("%.1f", stats.Regen) .. " HP/" .. text("Seconds"))
    end

    if stats.ContactDamage > 0 then
      table.insert(lines, text("Contact") .. ": " .. tostring(math.floor(stats.ContactDamage)))
    end

    if stats.HealAura > 0 then
      table.insert(lines, text("Aura") .. ": " .. tostring(stats.HealAura) .. " HP/" .. text("Seconds"))
    end

    if stats.Income > 0 then
      table.insert(lines, text("Income") .. ": +" .. tostring(stats.Income))
    end

    if stats.GunCount > 0 then
      table.insert(lines, text("Guns") .. ": " .. tostring(stats.GunCount))
    end

    if stats.EmergencyRepair ~= nil then
      table.insert(lines, text("Repair") .. ": " .. string.format("%d%% / %ds", stats.EmergencyRepair.Heal * 100, stats.EmergencyRepair.Cooldown))
    end

    if stats.Siege ~= nil then
      table.insert(lines, text("Siege") .. ": -" .. string.format("%d%%", stats.Siege.Reduction * 100))
    end

    if stats.Pulse ~= nil then
      table.insert(lines, text("Pulse") .. ": " .. tostring(stats.Pulse.Damage) .. " / " .. tostring(stats.Pulse.Interval) .. text("SecShort"))
    end

    if stats.Poison ~= nil then
      table.insert(lines, text("Poison") .. ": " .. tostring(stats.Poison.Dps) .. " x " .. tostring(stats.Poison.Duration) .. text("SecShort"))
    end

    if stats.KamikazeDamage > 0 then
      table.insert(lines, text("Kamikaze") .. ": " .. tostring(stats.KamikazeDamage))
    end

    if stats.FactoryCount > 0 then
      table.insert(lines, text("FactoryLines") .. ": " .. tostring(stats.FactoryCount) .. " x " .. V.WeaponName(design.Factory))
    end

    if stats.Cargo then
      table.insert(lines, text("Cargo") .. ": 6")
    end

    if stats.SwarmMax > 0 then
      table.insert(lines, text("Swarm") .. ": " .. tostring(stats.SwarmMax))
    end

    table.insert(lines, text("BuildTime") .. ": " .. tostring(math.floor(stats.BuildTime)) .. " " .. text("Seconds"))
    table.insert(lines, text("PartCount") .. ": " .. tostring(stats.PartCount)
      .. "  (+" .. tostring(math.floor(stats.PartBonus * 100 + 0.5)) .. "% " .. text("Health") .. ")")

    statsLabel:SetText(table.concat(lines, "\n"))

    local affordable = water >= stats.Cost
    if affordable then
      messageLabel:SetColor(colorHint)
      messageLabel:SetText(text("Hint"))
    else
      messageLabel:SetColor(errorColor)
      messageLabel:SetText(text("NotEnough") .. " (" .. tostring(math.floor(water)) .. " / " .. tostring(stats.Cost) .. ")")
    end

    buildButton:SetDisabled(false)
    saveDesign(design)
  end

  -- Events ---------------------------------------------------------------------------------------------------------------

  hullCombo.OnSelect = function(_, _, _, id)
    if refreshing or id == nil then return end

    state.Hull = id
    adjustToHull()
    syncControls()
    refresh()
  end

  wheelCombo.OnSelect = function(_, _, _, id)
    if refreshing or id == nil then return end

    state.Wheel = id
    refresh()
  end

  axlesSlider.OnValueChanged = function(_, value)
    if refreshing then return end

    state.Axles = math.floor(value + 0.5)
    refresh()
  end

  engineCombo.OnSelect = function(_, _, _, id)
    if refreshing or id == nil then return end

    state.Engine = id
    refresh()
  end

  armorCombo.OnSelect = function(_, _, _, id)
    if refreshing then return end

    state.Armor = id or ""
    refresh()
  end

  nameEntry.OnValueChange = function(_, value)
    if refreshing then return end

    state.Name = string.sub(value or "", 1, V.MaxNameLength)
  end

  factoryCombo.OnSelect = function(_, _, _, id)
    if refreshing or id == nil then return end

    state.Factory = id
    refresh()
  end

  -- Presets
  presetCombo:SetValue(text("PresetHint"))
  for index, preset in ipairs(presets) do
    presetCombo:AddChoice(V.Text(preset.Name), index)
  end

  presetCombo.OnSelect = function(_, _, _, index)
    local preset = presets[index]
    if preset == nil then return end

    local raw = V.CopyDesign(preset.Design)
    raw.Name = V.Text(preset.Name)

    -- Units that are not available for this faction (or too heavy for a mount) are skipped.
    local context = weaponContext()
    for i, id in ipairs(raw.Weapons) do
      if id ~= "" and (not V.IsWeaponUnit(id) or not context.IsWeaponAllowed(id)) then
        raw.Weapons[i] = ""
      end
    end

    local hull = V.GetPart("Hull", raw.Hull)
    if hull ~= nil then
      for i, mount in ipairs(hull.Mounts) do
        local id = raw.Weapons[i]
        if id ~= nil and id ~= "" and not V.MountAccepts(mount, id) then raw.Weapons[i] = "" end
      end
    end

    state = V.CopyDesign(raw)
    adjustToHull()
    syncControls()
    refresh()
  end

  buildButton.DoClick = function()
    if not MelonCommander.IsPlaying() then return end
    if not MelonCommander.IsPlayerActive(MelonCommander.GetLocalPlayer()) then return end

    local design = V.NormalizeDesign(state, weaponContext())
    if design == nil then return end

    gameplayPanel:Close()

    V.BeginPlacingVehicle(design)
  end

  root.OnRemove = function()
    if V.GarageResync ~= nil then V.GarageResync = nil end

    if visual ~= nil then
      V.RemoveVisual(visual)
      visual = nil
    end
  end

  -- Start ----------------------------------------------------------------------------------------------------------------

  -- Called when a chaos setting changes while the panel is open.
  local function resync()
    if not IsValid(root) then return end

    adjustToHull()
    syncControls()
    refresh()
  end

  V.GarageResync = resync

  adjustToHull()
  syncControls()
  refresh()

  local sheet = gameplayPanel.tabs:AddSheet(text("Tab"), root, "icon16/car.png")
  sheet.Tab.Paint = paintTab
  sheet.Tab:SetFont(MelonCommander.FontRegular)

  return sheet
end

-- Chaos settings in the "Tools" tab -----------------------------------------------------------------------------------

local settingTexts = {
  AnyUnit = {
    T("Любые юниты как оружие", "Any unit as a weapon"),
    T("Крепить можно любого юнита любой фракции, кроме зданий, самолётов и баз.", "Mount any unit of any faction except buildings, planes and bases.")
  },
  IgnoreFaction = {
    T("Юниты любых фракций", "Units of every faction"),
    T("Только оружейные юниты, но любых фракций и без запретов матча.", "Weapon units only, but from any faction and ignoring match bans.")
  },
  IgnoreMounts = {
    T("Любой вес на любом креплении", "Any weight on any mount"),
    T("Тяжёлое оружие можно ставить на лёгкие крепления.", "Heavy weapons fit light mounts.")
  },
  IgnoreLimits = {
    T("Без лимитов деталей", "No part limits"),
    T("+8 слотов модулей и декора, повторы модулей, любые колёса, до 10 пар колёс.", "+8 module/decor slots, duplicate modules, any wheels, up to 10 wheel pairs.")
  },
  Free = {
    T("Бесплатные машины", "Free vehicles"),
    T("Машины и их оружие ничего не стоят.", "Vehicles and their weapons cost nothing.")
  }
}

local function addChaosSettings(gameplayPanel)
  if not IsValid(gameplayPanel) then return end

  local tools = gameplayPanel.toolsTab
  if not IsValid(tools) then return end

  local isAdmin = LocalPlayer():IsAdmin()

  gameplayPanel.mcvChaosPanels = gameplayPanel.mcvChaosPanels or {}
  local tracked = gameplayPanel.mcvChaosPanels

  local header = vgui.Create("DLabel", tools)
  table.insert(tracked, header)
  header:SetFont(MelonCommander.FontRegular)
  header:SetColor(color_white)
  header:SetText(V.Text(T("Гараж: хаос", "Garage: chaos")) .. (isAdmin and "" or V.Text(T("  (только админ)", "  (admin only)"))))
  header:SetTall(20)
  header:DockMargin(8, 22, 6, 2)
  header:Dock(TOP)

  for _, key in ipairs(V.SettingOrder) do
    local texts = settingTexts[key]
    local convar = V.ConVars[key]

    local checkbox = vgui.Create("DCheckBoxLabel", tools)
    table.insert(tracked, checkbox)
    checkbox:SetFont(MelonCommander.FontRegular)
    checkbox:SetText(V.Text(texts[1]))
    checkbox:SetTextColor(color_white)
    checkbox:SetTall(18)
    checkbox:DockMargin(10, 8, 6, 0)
    checkbox:Dock(TOP)

    local loading = true
    checkbox:SetValue(convar ~= nil and convar:GetBool())
    loading = false

    checkbox:SetEnabled(isAdmin)

    checkbox.OnChange = function(_, value)
      if loading then return end

      RunConsoleCommand("melon_commander_vehicles_chaos", key, value and "1" or "0")
    end

    local description = vgui.Create("DLabel", tools)
    table.insert(tracked, description)
    description:SetFont(MelonCommander.FontWeak)
    description:SetColor(colorHint)
    description:SetText(V.Text(texts[2]))
    description:SetWrap(true)
    description:SetAutoStretchVertical(true)
    description:DockMargin(30, 1, 10, 0)
    description:Dock(TOP)
  end
end

local function removeChaosSettings(gameplayPanel)
  for _, panel in ipairs(gameplayPanel.mcvChaosPanels or {}) do
    if IsValid(panel) then panel:Remove() end
  end

  gameplayPanel.mcvChaosPanels = {}
end

-- Rebuilds the Garage tab and the chaos settings (used when the language changes).
function V.RebuildGarageUI(gameplayPanel)
  if not IsValid(gameplayPanel) or not IsValid(gameplayPanel.tabs) then return end

  local old = gameplayPanel.mcvGarageSheet
  if old ~= nil and IsValid(old.Tab) then
    gameplayPanel.tabs:CloseTab(old.Tab, true)
  end

  gameplayPanel.mcvGarageSheet = nil
  removeChaosSettings(gameplayPanel)

  local ok, sheet = pcall(buildGarageTab, gameplayPanel)
  if ok then
    gameplayPanel.mcvGarageSheet = sheet
  else
    ErrorNoHalt("[Melon Commander: Garage] failed to rebuild the Garage tab: " .. tostring(sheet) .. "\n")
  end

  pcall(addChaosSettings, gameplayPanel)

  if ok and sheet ~= nil and IsValid(sheet.Tab) then
    gameplayPanel.tabs:SetActiveTab(sheet.Tab)
  end
end

hook.Add(MelonCommander.Hook.BuildCommandPanel, "melon_commander_vehicles_garage", function(gameplayPanel)
  local ok, result = pcall(buildGarageTab, gameplayPanel)

  if ok then
    gameplayPanel.mcvGarageSheet = result
  else
    ErrorNoHalt("[Melon Commander: Garage] failed to build the Garage tab: " .. tostring(result) .. "\n")
  end

  -- The Tools tab is created right after this hook, so add to it on the next tick.
  timer.Simple(0, function()
    local settingsOk, settingsErr = pcall(addChaosSettings, gameplayPanel)

    if not settingsOk then
      ErrorNoHalt("[Melon Commander: Garage] failed to add chaos settings: " .. tostring(settingsErr) .. "\n")
    end
  end)
end)

-- Keep an open Garage tab in sync when an admin flips a setting.
for _, key in ipairs(V.SettingOrder) do
  cvars.AddChangeCallback(V.SettingConVarNames[key], function()
    timer.Simple(0.1, function()
      if V.GarageResync ~= nil then pcall(V.GarageResync) end
    end)
  end, "melon_commander_vehicles_garage_" .. key)
end

-- Placing a vehicle (player intent) ------------------------------------------------------------------------------------

local function removeGhost()
  if V.GhostVisual ~= nil then
    V.RemoveVisual(V.GhostVisual)
    V.GhostVisual = nil
    V.GhostCode = nil
  end
end

V.RemoveGhost = removeGhost

local function updateGhost(design)
  local code = V.EncodeCode(design)

  if V.GhostVisual == nil or V.GhostCode ~= code then
    removeGhost()

    V.GhostVisual = V.CreateVisual(design, true, false)
    V.GhostCode = code
  end

  local visual = V.GhostVisual
  local layout = visual.Layout

  local enginePlayer = LocalPlayer()
  local hitPos = enginePlayer:GetEyeTrace().HitPos

  local unitTemplate = MelonCommander.Units[V.UnitId]
  local rotation = unitTemplate ~= nil and unitTemplate.SpawnRotation or 0

  local origin = hitPos + Vector(0, 0, 4 - layout.Mins.z)
  local angles = Angle(0, enginePlayer:EyeAngles().y + rotation, 0)

  local ply = MelonCommander.GetLocalPlayer()
  local color = Color(255, 255, 255, 120)
  if ply ~= nil and ply.Color ~= nil then
    color = Color(ply.Color.r, ply.Color.g, ply.Color.b, 120)
  end

  V.UpdateVisual(visual, origin, angles, color, 0, 0, "ghost")
end

function V.BeginPlacingVehicle(design)
  if not MelonCommander.IsPlaying() then return end

  MelonCommander.ClearIntent()

  MelonCommander.LocalPlayerIntent = MelonCommander.CreatePlayerIntent(V.IntentKind, {
    Design = V.CopyDesign(design)
  })

  MelonCommander.ReplicateLocalPlayerIntent()
end

local function registerIntent()
  if MelonCommander.PlayerIntentImplementation == nil then return end

  MelonCommander.PlayerIntentParameterClasses[V.IntentKind] = { Design = nil }

  MelonCommander.PlayerIntentImplementation[V.IntentKind] = {
    ClientThink = function(intent)
      local design = intent.Parameters.Design
      if design == nil then return end

      updateGhost(design)
    end,

    DrawHUD = function(intent)
      local design = intent.Parameters.Design
      if design == nil then return end

      local stats = V.ComputeStats(design)
      if stats == nil then return end

      local hull = V.GetPart("Hull", design.Hull)
      local name = design.Name
      if name == nil or name == "" then name = V.Text(hull.Name) end

      local ply = MelonCommander.GetLocalPlayer()
      local canAfford = ply ~= nil and ply.Water >= stats.Cost

      local color = canAfford and color_white or errorColor
      MelonCommander.DrawTextUnderCrosshair(
        "Placing vehicle: " .. name .. " (-" .. tostring(stats.Cost) .. ")",
        color
      )

      return true
    end
  }
end

hook.Add("InitPostEntity", "melon_commander_vehicles_register_client_intent", registerIntent)
registerIntent()

-- Remove the ghost as soon as the player stops placing a vehicle (right click, another intent, ...).
hook.Add("Think", "melon_commander_vehicles_ghost_cleanup", function()
  if V.GhostVisual == nil then return end

  local intent = MelonCommander.LocalPlayerIntent
  if intent == nil or intent.Kind ~= V.IntentKind then
    removeGhost()
  end
end)
