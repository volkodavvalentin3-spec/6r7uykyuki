--[[
  Melon Commander: Garage - server side.

  - builds a vehicle from a blueprint (hull entity + units welded on its mounts as weapons)
  - "PlaceVehicle" player intent (left click = build at the crosshair, right click = cancel)
  - selling vehicles, damage reduction from armor/shield modules
]]--

local V = MelonCommander.Vehicles
local Base = MelonCommander.Expansions.Base

-- Messages shown to the player (bilingual, the server doesn't know the client's language).
local messages = {
  CantBuild = "Нельзя строить здесь / You can't build here.",
  CantAfford = "Не хватает воды / You can't afford this vehicle.",
  Banned = "Машины запрещены правилами / Vehicles are banned.",
  SellLate = "Нельзя продать — прошло 15 секунд / Can't sell that - 15 seconds passed since deployment."
}

local function notify(enginePlayer, text, snd)
  MelonCommander.SystemNotification(text, snd or "buttons/weapon_cant_buy.wav", enginePlayer)
end

-- Which units may this player bolt on a vehicle? (their faction list, minus banned units)
function V.GetWeaponContext(ply)
  local allowed = {}

  local faction = MelonCommander.Factions[ply.Faction]
  if faction ~= nil then
    for _, id in ipairs(faction.AvailableUnits or {}) do
      allowed[id] = true
    end
  end

  return {
    FactionId = ply.Faction,
    IsWeaponAllowed = function(id)
      if V.Setting("IgnoreFaction") or V.Setting("AnyUnit") then return true end

      return allowed[id] == true and MelonCommander.GameRules.BannedUnits[id] == nil
    end
  }
end

function V.IsVehicle(ent)
  return MelonCommander.IsEntityUnit(ent) and ent:GetUnitIdentifier() == V.UnitId
end

-- Creates a unit, welds it on the vehicle's mount and makes it behave like a turret.
local function attachWeapon(vehicle, mount, weaponId, plyIdentifier, totalBuildTime)
  local template = MelonCommander.Units[weaponId]
  if template == nil then return NULL end

  local weapon = MelonCommander.CreateUnit(weaponId)
  if not IsValid(weapon) then return NULL end

  weapon:SetUnitOwner(plyIdentifier)
  weapon:SetUnitIsTurret(true)
  weapon:UpdateOwnerColor()

  local weaponState = weapon:GetUnitState()
  weaponState.instantBuild = MelonCommander.GameRules.InstantBuild

  -- Everything finishes building together with the hull.
  weaponState.queueBuildDelay = math.max(0, totalBuildTime - (template.BuildTime or 0))

  local mountPos = vehicle:LocalToWorld(V.ToEntityLocal(mount.Pos))
  local forwardYaw = vehicle:GetAngles().y + V.FrontYaw

  weapon:SetPos(mountPos + Vector(0, 0, 16))
  weapon:SetAngles(Angle(0, forwardYaw + (template.SpawnRotation or 0), 0))
  weapon:Spawn()

  if not IsValid(weapon) then return NULL end

  local mins = weapon:OBBMins()
  weapon:SetPos(mountPos + Vector(0, 0, 1 - mins.z))

  local weaponPhys = weapon:GetPhysicsObject()
  if IsValid(weaponPhys) and weapon:GetMoveType() == MOVETYPE_VPHYSICS then
    constraint.Weld(weapon, vehicle, 0, 0, 0, true, false)
  else
    -- Static units (buildings, towers, ...) can't be welded; chaos mode parents them to the hull instead.
    weapon:SetParent(vehicle)
  end

  -- If a weapon dies on its own, the vehicle must not be refunded for it any more.
  local weaponCost = V.WeaponCost(weaponId)
  weapon:CallOnRemove("mcv_weapon_removed", function()
    if IsValid(vehicle) and vehicle.VehicleStats ~= nil and not vehicle.McvRemoving then
      vehicle.VehicleStats.Cost = math.max(0, vehicle.VehicleStats.Cost - weaponCost)
    end
  end)

  return weapon
end

--[[
  Builds the hull and all of its weapons. The blueprint must already be normalized.
  Doesn't touch the player's water, see PlaceVehicle below.
]]--
function V.SpawnVehicle(plyIdentifier, design, stats, layout, hitPos, eyeAngles)
  local unitTemplate = MelonCommander.Units[V.UnitId]
  if unitTemplate == nil then return NULL end

  local vehicle = MelonCommander.CreateUnit(V.UnitId)
  if not IsValid(vehicle) then return NULL end

  -- Per-vehicle values read by the VehicleBody component on spawn
  vehicle.VehicleDesign = design
  vehicle.VehicleStats = table.Copy(stats)

  vehicle:SetUnitOwner(plyIdentifier)
  vehicle:SetUnitIsTurret(false)
  vehicle:UpdateOwnerColor()

  local vehicleState = vehicle:GetUnitState()
  vehicleState.instantBuild = MelonCommander.GameRules.InstantBuild
  vehicleState.queueBuildDelay = stats.BuildTime

  -- Per-vehicle locomotor: same ground movement, speed comes from wheels, engine and weight.
  vehicleState.LocomotorTemplate = MelonCommander.Utility.Table.ReadOnly({
    MoveType = MelonCommander.LocomotorMoveType.Ground,
    Speed = stats.Speed,
    Height = 0,
    FlyCircleAround = false,
    AlterHeight = false
  })

  -- "Extra machine gun" modules: the hull itself shoots (more modules = faster fire).
  if stats.GunCount > 0 then
    local gun = V.BuildGunWeapon(stats.GunCount)

    if gun ~= nil then
      vehicleState.WeaponTemplate = MelonCommander.Utility.Table.ReadOnly(gun)
      vehicleState.WeaponState = {
        NextAttack = 0.0,
        Clip = gun.ClipSize,
        NextLeap = 0.0,
        NextTargetSearch = 0.0
      }
    end
  end

  vehicle:SetPos(hitPos + Vector(0, 0, 4 - layout.Mins.z))
  vehicle:SetAngles(Angle(0, eyeAngles.y + unitTemplate.SpawnRotation, 0))
  vehicle:Spawn()

  if not IsValid(vehicle) then return NULL end

  vehicle.VehicleWeaponUnits = {}

  for index, mount in ipairs(layout.Mounts) do
    local weaponId = design.Weapons[index]

    if weaponId ~= nil and weaponId ~= "" then
      local weapon = attachWeapon(vehicle, mount, weaponId, plyIdentifier, stats.BuildTime)

      if IsValid(weapon) then
        table.insert(vehicle.VehicleWeaponUnits, weapon)
      end
    end
  end

  return vehicle
end

-- Intent: place a vehicle at the crosshair -------------------------------------------------------------

local function placeVehicle(intent, ply, enginePlayer, plyIdentifier)
  if not IsValid(enginePlayer) then return true end

  if plyIdentifier == nil then
    plyIdentifier = MelonCommander.GetPlayerIdentifierFromEngine(enginePlayer)
  end

  if MelonCommander.GameRules.BannedUnits[V.UnitId] ~= nil then
    notify(enginePlayer, messages.Banned)
    return true
  end

  local design, err = V.NormalizeDesign(intent.Parameters.Design, V.GetWeaponContext(ply))
  if design == nil then
    notify(enginePlayer, tostring(err))
    return true
  end

  local stats = V.ComputeStats(design)
  local layout = V.ComputeLayout(design)

  local hitPos = enginePlayer:GetEyeTrace().HitPos

  local space = math.min(layout.Radius * 0.6, 45)
  if not MelonCommander.CanBuildAt(plyIdentifier, hitPos, space) then
    notify(enginePlayer, messages.CantBuild)
    return false
  end

  if not MelonCommander.CanPlayerAfford(ply, stats.Cost) then
    notify(enginePlayer, messages.CantAfford)
    return false
  end

  local vehicle = V.SpawnVehicle(plyIdentifier, design, stats, layout, hitPos, enginePlayer:EyeAngles())
  if not IsValid(vehicle) then return false end

  local canPurchase = hook.Call(MelonCommander.Hook.UnitPurchased, nil, plyIdentifier, V.UnitId, vehicle)
  if canPurchase == false then
    vehicle:Remove()
    return false
  end

  MelonCommander.TakePlayerWater(ply, stats.Cost, MelonCommander.TakeWaterReason.PurchasedUnit)
  MelonCommander.ReplicatePlayers()

  notify(enginePlayer, nil, "ui/buttonclickrelease.wav")
  return false, vehicle
end

-- Selling ----------------------------------------------------------------------------------------------------

local function sellVehicle(ply, enginePlayer, vehicle)
  if CurTime() - vehicle:GetUnitBuildFinishesAt() > 15 then
    notify(enginePlayer, messages.SellLate)
    return
  end

  local refund = vehicle.VehicleStats.Cost
  if vehicle:IsFinishedBuilding() then
    refund = refund / 2.0
  end

  refund = math.floor(refund)

  MelonCommander.GivePlayerWater(ply, refund, MelonCommander.GiveWaterReason.SoldUnit)
  sound.Play("garrysmod/balloon_pop_cute.wav", vehicle:GetPos(), 75, 100, 1)

  notify(enginePlayer, "Sold vehicle for "..tostring(refund).." water.", "")

  vehicle.McvRemoving = true
  vehicle:Remove()
end

local function wrapSellIntent(impl)
  if impl == nil or impl.McvWrapped then return end

  local original = impl.PerformPrimaryAction

  impl.PerformPrimaryAction = function(intent, ply, enginePlayer, ...)
    if IsValid(enginePlayer) then
      local hitEntity = enginePlayer:GetEyeTrace().Entity
      local plyIdentifier = MelonCommander.GetPlayerIdentifierFromEngine(enginePlayer)

      if V.IsVehicle(hitEntity) and hitEntity:IsInGame() and hitEntity:GetUnitOwner() == plyIdentifier
          and hitEntity.VehicleStats ~= nil then
        sellVehicle(ply, enginePlayer, hitEntity)
        return false
      end
    end

    return original(intent, ply, enginePlayer, ...)
  end

  impl.McvWrapped = true
end

-- Registration -------------------------------------------------------------------------------------------------

local function registerImplementation()
  local implementations = MelonCommander.PlayerIntentImplementation
  if implementations == nil then return end

  implementations[V.IntentKind] = {
    PerformPrimaryAction = placeVehicle,
    PerformSecondaryAction = function(intent, ply, enginePlayer) return true end
  }

  wrapSellIntent(implementations[MelonCommander.PlayerIntentKind.SellUnit])
end

-- server/intent.lua of Melon Commander is loaded after the expansions, so register once everything is up.
hook.Add("InitPostEntity", "melon_commander_vehicles_register_intent", registerImplementation)
registerImplementation()

-- Armor / shield modules reduce incoming damage.
hook.Add(MelonCommander.Hook.UnitDamaged, "melon_commander_vehicles_damage_reduction", function(ent, attacker, amount, oldHealth, newHealth)
  if not IsValid(ent) then return end

  local stats = ent.VehicleStats
  if stats == nil then return end

  local mult = stats.DamageMult

  -- Empire bastion: dug in while standing still.
  if stats.Siege ~= nil then
    local data = ent:GetComponentState(V.ComponentId)
    if data ~= nil and data.Sieged then mult = mult * (1 - stats.Siege.Reduction) end
  end

  if mult >= 1 then return end

  return true, amount * mult
end)


-- Chaos settings -------------------------------------------------------------------------------------------------------

concommand.Add("melon_commander_vehicles_chaos", function(enginePlayer, command, args)
  if IsValid(enginePlayer) and not enginePlayer:IsAdmin() then
    notify(enginePlayer, "Только для админов / Admins only.")
    return
  end

  local convar = V.ConVars[args[1] or ""]
  if convar == nil then return end

  local value = args[2]
  convar:SetBool(value == "1" or value == "true")
end)
